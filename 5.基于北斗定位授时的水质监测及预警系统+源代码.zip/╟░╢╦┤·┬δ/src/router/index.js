import Vue from 'vue'
import VueRouter from 'vue-router'

import routes from './routes'

Vue.use(VueRouter)

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

const Router = new VueRouter({
  scrollBehavior: () => ({
    x: 0,
    y: 0
  }),
  routes:[...routes],
  // mode: 'history',
  base: process.env.VUE_ROUTER_BASE,
})

// 添加动态路由
// export const initRouters = () => {
//   // console.log(Router);
//   // 对路由规则进行动态的添加
//   const currRoutes = Router.options.routes
//   // 从sessionStorage中获取到菜单数据
//   const rightList = JSON.parse(sessionStorage.getItem('menulist'))
//   // 将菜单数据获取到后循环遍历每一条的数据
//   rightList.forEach(item => {
//     // 获取到routers.js文件中的ruleMapping对象，
//     // item是指菜单中的数据
//     const temp = ruleMapping[item.path]
//     if (temp) {
//       if (!temp.meta) {
//         temp.meta = {}
//       }
//       //给当前的对象添加元数据，元数据中存储的是按钮的权限
//       temp.meta.right = item.right
//       // 在对应的路由中的child动态添加路由
//       currRoutes[2].children.push(temp)
//     }
//   })
//   Router.addRoutes(currRoutes)
// }

// 这样能直接解决刷新页面后，页面依旧存在的问题
sessionStorage.getItem('userId')

//挂载路由导航守卫
// Router.beforeEach((to, from, next) => {
//   if (to.path === '/login') return next()
//   const userId = sessionStorage.getItem('userId')
//   if (!userId) return next('/login')
//   next()
// }
// )
  
export default Router

