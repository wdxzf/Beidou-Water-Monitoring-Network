
const routes = [{
        path: '/',
        redirect: '/login'
    },
    {
        path: "/login",
        component: () => import("@/pages/user/login.vue"),
    }, {
        path: "/index",
        name: "index",
        component: () => import("@/pages/home/index.vue"),
        redirect: "/welcome",
        children: [{
                path: "/welcome",
                name: "welcome",
                component: () => import("@/pages/home/welcome.vue"),
                meta: {
                    title: "",
                    icon: "dashboard"
                },
            }, {
                path: "/invest",
                name: "invest",
                title:"投资管理",
                component: () => import("@/pages/home/invest.vue")
            }, {
                path: "/mySelf",
                name: "mySelf",
                component: () => import("@/pages/mySelf/mySelf.vue"),
                meta: {
                    title: "个人中心",
                    icon: "dashboard"
                },
            },
            {
                path: "/area",
                name: "area",
                title:"地区",
                component: () => import("@/pages/home/area.vue"),
            },
            {
                path: "/manage",
                name: "manage",
                title:"设备管理",
                component: () => import("@/pages/home/equipment/manage.vue"),
            },
            {
                path: "/data",
                name: "data",
                title:"设备数据",
                component: () => import("@/pages/home/equipment/data.vue"),
            },
            {
                path: "/reqairs",
                name: "reqairs",
                title:"设备数据",
                component: () => import("@/pages/home/equipment/repairs.vue"),
            },
            {
                path: "/our",
                name: "our",
                title:"关于我们",
                component: () => import("@/pages/home/our.vue"),
            },
            {
                path: "/mySelf",
                name: "mySelf",
                component: () => import("@/pages/mySelf/mySelf.vue"),

            },
            {
                path: "/equipment",
                name: "equipment",
                component: () => import("@/pages/home/equipment/equipment.vue")
            },
        ],
    },
    {
        path: '*',
        name: '404',
        component: () => import("@/pages/error/404.vue")
    }
];

export default routes