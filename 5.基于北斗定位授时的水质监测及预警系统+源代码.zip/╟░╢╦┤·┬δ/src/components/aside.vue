<template>
  <div>
    <el-menu
      background-color="#333744"
      text-color="#fff"
      active-text-color="#409eff"
      router
      unique-opened
      :collapse="isCollapse"
      :collapse-transition="false"
      :default-active="activePath"
    >
      <!-- 一级菜单 -->
      <el-menu-item index="/welcome">
        <i class="el-icon-s-home"></i>
        <span slot="title">首页</span>
      </el-menu-item>

      <el-menu-item index="/invest">
        <i class="el-icon-s-data"></i>
        <span slot="title">投资管理</span>
      </el-menu-item>

      <!-- <el-menu-item index="/area">
        <i class="el-icon-location"></i>
        <span slot="title">地区</span>
      </el-menu-item> -->

      <el-submenu index="3">
        <template slot="title">
          <i class="el-icon-s-grid"></i>
          <span>设备</span>
        </template>
        <el-menu-item index="/manage">设备管理</el-menu-item>
        <el-menu-item index="/data">设备数据</el-menu-item>
        <!-- <el-menu-item index="/reqairs">设备报修</el-menu-item> -->
      </el-submenu>

      <el-menu-item index="/our">
        <i class="el-icon-thumb"></i>
        <span slot="title">关于我们</span>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script>
export default {
  props: ["isCollapse"],
  data() {
    return {
      // 保存被激活的链接地址
      activePath: "",
      // 获取到菜单的数据
      menulist: JSON.parse(sessionStorage.getItem("menulist")),
    };
  },
  created() {
    this.activePath = window.localStorage.getItem("activePath");
  },
  methods: {
    // 保存链接的激活状态
    saveNavState(activePath) {
      // 由于之前点击链接后高亮了，但是点击另一个后，在此点击之前那个就不亮了，所以需要将值重新输入this.activePath中去
      this.activePath = activePath;
      window.localStorage.setItem("activePath", activePath);
    },
  },
};
</script>
