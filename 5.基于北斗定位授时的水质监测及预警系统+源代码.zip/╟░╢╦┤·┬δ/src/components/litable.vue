<template>
  <div>
    <!-- table下的子组件利用v-for循环复用 -->
    <el-table
      :border="border1"
      :data="tableData"
      stripe
      style="width: 100%"
      @selection-change="handleSelectionChange"
      :header-cell-style="{ background: '#eee', color: '#606266' }"
      @cell-click="cellClick"
    >
      <!-- 序列 -->
      <slot name="order"></slot>
      <!-- 选择框 -->
      <slot name="select"></slot>
      <slot name="bottom"></slot>
      <!-- 表格的值 -->
      <el-table-column
        v-for="(item, key) in tableKey"
        :key="key"
        :prop="item.value"
        :label="item.name"
        :width="item.width"
        :formatter="formatBoolean"
        :id="'judge' + item.value"
      ></el-table-column>
      <slot name="top"></slot>
    </el-table>
  </div>
</template>

<script>
export default {
  //接收父组件传的值
  // props: ['tableData', 'tableKey', 'border'],
  props: {
    // 表格数据
    tableData: {
      type: Array,
      default: () => []
    },
    // 每一列的对应的key
    tableKey: {
      type: Array,
      default: () => []
    },
    border: Boolean
  },
  data() {
    return {
      multipleSelection: [],
      border1: false
    }
  },
  created() {
    this.border1 = this.border //显示表格的框
  },
  methods: {
    cellClick(row, column, cell, event) {
      this.$emit('cellClick', row, column, cell, event)
    },
    handleSelectionChange(val) {
      this.multipleSelection = val
      console.log(this.multipleSelection)
      this.$emit('multipleSelection', this.multipleSelection)
    },
    //选中的复选框的值传给父组件
    selectInfo() {},
    formatBoolean(row, column, cellValue) {
      var ret = cellValue //你想在页面展示的值
      if (typeof cellValue === 'boolean') {
        if (cellValue) {
          ret = '是' //根据自己的需求设定
        } else {
          ret = '否'
        }
      }
      return ret
    }
  }
}
</script>

<style lang="less" scoped>
.el-table {
  margin: 10px 0px;
}

/deep/.el-table {
  td,
  th {
    position: relative;
    text-align: center;
  }
}
</style>
