import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    nickname: sessionStorage.getItem('nickname')
  },
  mutations: {
    setUserName(state, data){
        state.nickname = data;
        sessionStorage.setItem('nickname', data)
    }
  },
  actions: {
  },
  modules: {
  }
})