import index from '../router/index'
import Vue from 'vue'

// 设置自定义指令，并进行插入
// 自定义权限，用户有该权限
Vue.directive('has', {
    inserted(el, binding) {
        const action = binding.value.action
        // 判断当前自定义指令的按钮是否写了effect: 'disabled'，这表示写了这个就进行隐藏
        // v-has="{action: 'userMinfo:insert', effect: 'disabled'}"
        const effect = binding.value.effect
        // currentRoute得到当前的当前所处于的组件路由规则
        // console.log(index.currentRoute.meta.right , '===meta');
        // 菜单数据下的所有按钮权限
        const rule = index.currentRoute.meta.right
        // 判断是否有  indexOf() 方法可返回某个指定的字符串值在字符串中首次出现的位置
        // 没有权限
        if (rule.indexOf(action) === -1) {
            handle(el, effect)
        }
    }
})

function handle(el, effect) {
    if (effect === 'disabled') {
        el.disabled = true
        el.classList.add('el-disabled', 'is-disabled')
    } else {
        el.parentNode.removeChild(el)
    }
}


// 自定义防止按钮短时间内多次点击的自定义事件
let handler = null;
Vue.directive('preventClick', {
    inserted(el) {
        let timer = null;
        handler = () => {
            el.disabled = true;
            el.classList.add('is-disabled');
            timer = setInterval(() => {
                if (window.done) {
                    clearInterval(timer);
                    el.disabled = false;
                    el.classList.remove('is-disabled');
                }
            }, 500);
        }
        el.addEventListener('click', handler)
    },
    unbind(el) {//自定义指令生命周期：unbind 
        document.removeEventListener('click', el.handler)
    }
})