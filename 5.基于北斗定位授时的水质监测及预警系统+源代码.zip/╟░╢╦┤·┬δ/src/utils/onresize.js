import Vue from 'vue'

Vue.directive('onresize',{
    bind(){
      window.onresize (function () {
        console.log('123');
        window.location.reload()
      })
    }
})