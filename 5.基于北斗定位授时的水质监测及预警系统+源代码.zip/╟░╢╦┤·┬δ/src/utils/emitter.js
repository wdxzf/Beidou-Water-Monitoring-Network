import Vue from 'vue'

const eventVue = new Vue()

export default eventVue