import axios from 'axios'
import router from '../router/index'
import { Message } from 'element-ui';

axios.defaults.withCredentials = true;//携带

let base_url = ""

switch (process.env.NODE_ENV) {
    case 'dev':
        base_url = process.env.VUE_APP_DEV
        break;
    default:
        base_url = process.env.VUE_APP_DEV
        break;
}

const HTTP_CONFIG = {
    timeout: 1000 * 60 * 30,
    baseURL: base_url,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    }
}

axios.defaults.withCredentials = true;//携带

Object.entries(HTTP_CONFIG).forEach(([key, value]) => {
    axios.defaults[key] = value
})

// 映射
// const actionMapping = {
//     get: 'view',
//     post: 'add',
//     put: 'edit',
//     delete: 'delete'
// }

/* 记录当前请求是否完成 */
window.done =  true,
// 请求拦截器配置
axios.interceptors.request.use(config => {
    window.done =  false
    // 在发送请求之前做些什么
    // if (config.url != '/login') {
    //     // 不是登录请求，我们应该在请求头中加入token数据
    //     // 判断是否存在token，如果存在的话，则每个http header都加上token
    //     // let token = window.localStorage.getItem('token')
    //     // config.headers.token = token;
    //     // 根据请求，得到那种操作
    //     const action = actionMapping[config.method]
    //     console.log(router.currentRoute);
    //     // 判断非权限范围内的请求
    //     const currentRight = router.currentRoute.meta
    //     console.log(currentRight)
    //     // 判断当前请求的行为与restful风格相关
    //     // get请求     view
    //     // post请求    add
    //     // put请求     edit
    //     // delete请求  delete
    //     if (currentRight && currentRight.indexOf(action) === -1) {
    //         // 暂无权限
    //         alert('暂无权限')
    //         return Promise.reject(new Error('暂无权限'))
    //     }
    // }
    return config;
}, error => {
    // 对请求错误做些什么
    return Promise.reject(error);
});

// 响应拦截器配置
axios.interceptors.response.use(response => {
    if (Object.keys(response).length != 0) {
        console.log("===--=-=-hahah ");
        window.done =  true
    }
    // 判断token失效，如果有token就会有失效的时间，那么就必须要强制他进行登录
    //  444为用户未登录，所以需要跳转到登录页面
    if (response.data.code === 402) {
        Message.error({ message: response.data.message });
        router.push('/login')
        // 将sessionStorage中的数据进行清空
        sessionStorage.clear()
        // 在进行刷新
        window.location.reload()
    }
    return response;
}, error => {
    // 对请求错误做些什么
    return Promise.reject(error);
})

// get请求
export function get(url) {
    return (data = {}, config) => Promise.resolve(
        axios.get(url, data, config).then(response => response.data)
    )

}

// post请求
export function post(url) {
    return (data = {}, config) => Promise.resolve(
        axios.post(url, data, config).then(response => response.data)
    )

}