import { post } from "utils/http";
 export default 
 { updateUserInfo: post("/user/updateUserInfo") };