import { post } from "utils/http";
 export default 
 { queryUserInfo: post("/user/queryUserInfo") };