import { post } from 'utils/http'

export default {
    getMenu: post('/getMenu')
}