import { post } from "utils/http";
 export default 
 { login: post("/user/login") };