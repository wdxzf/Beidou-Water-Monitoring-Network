import { post } from "utils/http";
 export default 
 { queryNowPower: post("/dataCollect/queryNowPower") };
 