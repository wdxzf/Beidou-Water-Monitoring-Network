import { post } from "utils/http";
 export default 
 { queryPower: post("/dataCollect/queryPower") };
 