import { post } from "utils/http";
 export default 
 { queryPDataCount: post("/dataCollect/queryPDataCount") };