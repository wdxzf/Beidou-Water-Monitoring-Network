import { post } from "utils/http";
 export default 
 { queryDeviceDetails: post("/device/queryDeviceDetails") };