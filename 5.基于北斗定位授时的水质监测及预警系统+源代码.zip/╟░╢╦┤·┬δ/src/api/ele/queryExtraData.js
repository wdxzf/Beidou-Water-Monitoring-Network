import { post } from "utils/http";
 export default 
 { queryExtraData: post("/dataCollect/queryExtraData") };