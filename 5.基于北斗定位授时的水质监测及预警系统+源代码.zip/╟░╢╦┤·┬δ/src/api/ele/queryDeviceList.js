import { post } from "utils/http";
 export default 
 { queryDeviceList: post("/device/queryDeviceList") };