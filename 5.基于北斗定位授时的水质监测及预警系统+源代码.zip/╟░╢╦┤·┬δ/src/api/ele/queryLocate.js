import { post } from "utils/http";
 export default 
 { queryLocate: post("/dataCollect/queryLocate") };
 