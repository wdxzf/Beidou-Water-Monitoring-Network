import { post } from 'utils/http'

export default {
    getUserInfo: post('/getUserInfo')
}