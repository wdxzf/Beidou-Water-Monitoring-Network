import { post } from 'utils/http'

export default {
    updatePersonalInfo: post('/updatePersonalInfo')
}