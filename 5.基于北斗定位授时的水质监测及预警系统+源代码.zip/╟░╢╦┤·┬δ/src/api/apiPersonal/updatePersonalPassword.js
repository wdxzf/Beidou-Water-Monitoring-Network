import { post } from 'utils/http'

export default {
    updatePersonalPassword: post('/updatePersonalPassword')
}