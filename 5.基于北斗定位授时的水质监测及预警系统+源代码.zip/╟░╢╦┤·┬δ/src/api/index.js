//登录
import login from "./login"
// 查询菜单数据
import getMenu from '@/api/getMenu'

//设备
import deleteDevice from "./apiDevcie/deleteDevice";
import getAddress from "./apiDevcie/getAddress";
import getDeviceInfo from "./apiDevcie/getDeviceInfo";
import getDeviceList from "./apiDevcie/getDeviceList";
import updateDeviceInfo from "./apiDevcie/updateDeviceInfo";
import addDevice from "./apiDevcie/addDevice";
// 个人中心
// 查询登录成功后的用户信息
import getUserInfo from '@/api/apiPersonal/getUserInfo'
import updatePersonalPassword from '@/api/apiPersonal/updatePersonalPassword'
// import updatePersonalInfo from '@/api/apiPersonal/updatePersonalInfo'
import updateUserInfo from '@/api/updateUserInfo.js' //修改个人信息
import queryUserInfo from '@/api/queryUserInfo.js'


//物联网光伏
import queryPower from '@/api/ele/queryPower'
import queryNowPower from '@/api/ele/queryNowPower'
import queryExtraData from '@/api/ele/queryExtraData'
import queryLocate from '@/api/ele/queryLocate.js'
import queryDeviceList from '@/api/ele/queryDeviceList.js'
import queryPDataCount from '@/api/ele/queryPDataCount.js'
import workParameters from '@/api/ele/workParameters.js'
import queryDeviceDetails from '@/api/ele/queryDeviceDetails.js'

export default {
    login,  // 登录
    getMenu, // 显示菜单数据
    // 个人中心
    getUserInfo, // 查询登录成功后的用户信息
    updatePersonalPassword, //修改密码
    // updatePersonalInfo, //修改个人信息
    updateUserInfo, //修改个人信息
    queryUserInfo, //获取修改后的信息


    //物联网光伏
    queryPower,
    queryNowPower,
    queryExtraData,
    queryLocate,
    queryDeviceList,
    queryPDataCount,//查询设备过去一年内的历史提交次数
    workParameters,
    queryDeviceDetails, //设备详情信息

    //设备
    deleteDevice,
    getDeviceList,
    getDeviceInfo,
    updateDeviceInfo,
    getAddress,
    addDevice
}
