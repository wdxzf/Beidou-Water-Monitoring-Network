import { post } from 'utils/http'

export default {
  getDeviceList: post('/device/queryDeviceList')
}