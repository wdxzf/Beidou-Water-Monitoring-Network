import { post } from 'utils/http'

export default {
  getDeviceInfo: post('/device/queryDeviceDetails')
}