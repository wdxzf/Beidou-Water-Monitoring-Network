import { post } from 'utils/http'

export default {
  deteleDevice: post('/device/deleteDevice')
}