import { post } from 'utils/http'

export default {
  addDevice: post('/device/addDevice')
}