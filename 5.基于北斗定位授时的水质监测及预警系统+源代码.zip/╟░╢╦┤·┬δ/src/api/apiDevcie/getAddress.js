import { post } from 'utils/http'

export default {
  getAddress: post('/device/queryAddress')
}