<template>
  <div>
    <el-row>
      <el-col :span="6">
        <el-card style="width: 90%; height: 180px; margin-left: 50px">
          <div v-for="item in lalalaA" :key="item.index">
            <p>
              <i :class="item.icon"></i>{{ item.lable
              }}<span>{{ item.label + "" }}</span>
              <span style="float: right">{{ item.value }}</span>
            </p>
            <el-divider></el-divider>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card style="width: 90%; height: 180px; margin-left: 50px">
          <div v-for="item in lalalaB" :key="item.index">
            <p>
              <i :class="item.icon"></i>{{ item.lable
              }}<span>{{ item.label }}</span>
              <span style="float: right">{{ item.value }}</span>
            </p>
            <el-divider></el-divider>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card style="width: 90%; height: 180px; margin-left: 50px">
          <div v-for="item in lalalaC" :key="item.index">
            <p>
              <i :class="item.icon"></i>{{ item.lable
              }}<span>{{ item.label }}</span>
              <span style="float: right">{{ item.value }}</span>
            </p>
            <el-divider></el-divider>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card style="width: 90%; height: 180px; margin-left: 50px">
          <div v-for="item in lalalaD" :key="item.index">
            <p>
              <i :class="item.icon"></i>{{ item.lable
              }}<span>{{ item.label }}</span>
              <span style="float: right">{{ item.value }}</span>
            </p>
            <el-divider></el-divider>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="24">
        <el-card style="width: 90%; margin-top: 1%; margin-left: 50px">
          <el-col :span="18">
            <div ref="myechart" style="width: 800px; height: 400px"></div>
          </el-col>
          <el-col :span="6">
            <div
              v-for="item in lalala"
              :key="item.index"
              style="margin-top: 50px"
            >
              <p>
                <i :class="item.icon"></i>{{ item.lable
                }}<span>{{ item.label }}</span>
                <span style="float: right">{{ item.value }}</span>
              </p>
              <el-divider></el-divider>
            </div>
          </el-col>
        </el-card>
      </el-col>
    </el-row>
    <el-row>
      <el-card
        style="width: 100%; height: 300px; margin-top: 1%; margin-left: 50px"
      >
        历史数据
        <div v-for="item in lalalaM" :key="item.index">
          <p>
            <el-col :span="12">
              <p style="float: left">
                <i :class="item.icon"></i>{{ item.lable }}
                <span>{{ item.name }} </span>
                {{ item.title }}
                <el-divider></el-divider>
              </p>
            </el-col>
          </p>
        </div>
      </el-card>
    </el-row>
  </div>
</template>

<script>
import api from "api";
import moment from "moment";
export default {
  data() {
    return {
      lalala: [
        { label: "平均温度", value: "30度" },
        { label: "平均湿度", value: "14%" },
        { label: "平均电功率", value: "3W" },
      ],
      lalalaA: [
        { label: "设备一", value: "正常" },
        { label: "A区", value: "" },
      ],
      lalalaB: [
        { label: "设备二", value: "正常" },
        { label: "B区", value: "" },
      ],
      lalalaC: [
        { label: "设备三", value: "关闭" },
        { label: "xx大学-学生宿舍7栋", value: "" },
      ],
      lalalaD: [
        { label: "设备四", value: "正常" },
        { label: "xx大学-教师宿舍52栋", value: "" },
      ],
      lalalaM: [
        {
          name: "七月",
          icon: "el-icon-arrow-down",
          title: "记录天数:23天",
        },
        {
          name: "八月",
          icon: "el-icon-arrow-down",
          title: "记录天数:28天",
        },
        {
          name: "九月",
          icon: "el-icon-arrow-down",
          title: "记录天数:18天",
        },
      ],

      eleData: [],
      timeData: [],
      TemData: ["1", "2", "3", "2", "1"],
      humData: ["2", "5", "1", "6", "3"],
      measureTime1: "",
      measureTime2: "",
      option: {
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: this.timeData,
        },

        yAxis: {
          type: "value",
        },

        series: [
          {
            data: this.eleData,
            type: "line",
          },
        ],
      },
    };
  },
  watch: {
    eleData() {
      this.setChart();
    },
    timeData() {
      this.setChart();
    },
  },
  mounted() {
    this.setChart();
  },
  created() {
    this.queryPowerL();
    this.queryExtraDataL();
    this.showFlash();
  },
  methods: {
    showFlash() {
      setInterval(() => {
        this.queryPowerL();
      }, 2500);
    },
    async queryPowerL() {
      // eslint-disable-next-line no-undef
      // var startTime = new Date();
      // this.measureTime1 = moment(startTime.getTime()).format(
      // "YYYY-MM-DD HH:mm:ss"
      // );
      /*  this.measureTime2 = moment(startTime.getTime()).format(
         "YYYY-MM-DD HH:mm:ss"
       ); */
      const data1 = await api.queryPower.queryPower({
        deviceId: "1",
      });
      this.eleData = [];
      this.timeData = [];
      for (let i = 0; i < data1.data.length; i++) {
        console.log(data1.data[i].electricityPower);
        this.eleData.push(data1.data[i].electricityPower);
        data1.data[i].measureTime = moment(data1.data[i].measureTime).format(
          "YYYY-MM-DD HH:mm:ss"
        );
        this.timeData.push(data1.data[i].measureTime);
      }
      console.log(this.eleData, "0000");
    },

    async queryExtraDataL() {
      const data2 = await api.queryExtraData.queryExtraData({
        deviceId: "2",
      });
      (this.TemData = data2.dataTemperature),
        (this.humData = data2.dataHumidity);
    },

    setChart() {
      console.log(this.eleData, "1000");
      console.log(this.timeData, "1000");
      var myChart = this.$echarts.init(this.$refs.myechart);
      this.option = {
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: this.timeData,
        },

        yAxis: {
          type: "value",
        },

        series: [
          {
            name: "光能数据",
            data: this.eleData,
            type: "line",
          },
        ],
      };

      console.log(this.option);
      myChart.setOption(this.option);
    },
  },
};
</script>

<style lang="less" scoped>
.navFather1 {
  width: 45%;
  margin-top: 150px;
}
.navFather2 {
  width: 31%;
  margin-top: 150px;
}
.nav {
  width: 240px;
  height: 120px;
  color: aliceblue;
  background-color: burlywood;
  cursor: pointer;
  p {
    padding-top: 15%;
    i {
      font-size: 50px;
      vertical-align: middle;
      margin-right: 10px;
    }
  }
}
.link {
  text-decoration: none;
}
</style>
