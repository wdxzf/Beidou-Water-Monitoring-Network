<template>
  <div class="box" align="center">
    <p class="errInfo">404</p>
    <p class="errInfo2">
      你访问的页面已丢失，正在努力寻找中
      <br />
      <br />
      <el-button type="warning" round plain style="backBtn" @click="backIndex"
        >返回首页</el-button
      >
    </p>
  </div>
</template>
<script type="text/javascript" src="//qzonestyle.gtimg.cn/qzone/hybrid/app/404/search_children.js" charset="utf-8"></script>
<script>
export default {
  methods: {
    backIndex() {
      this.$router.push({
        path: "/index"
      });
    }
  }
};
</script>


<style lang="less" scope>
.box {
  width: 100%;
  height: 100%;
  background-image: url("../../assets/one.gif");
  background-repeat: no-repeat;
  background-size: cover;
  -webkit-background-size: 39%;
  -o-background-size: cover;
  background-position: 46% 5%;
}
.errInfo {
  font-size: 100px;
  color: burlywood;
  padding-top: 2%;
}
.errInfo2 {
  font-size: 18px;
  margin-top: 230px;
  height: 50px;
  margin-bottom: 30px;
  color: burlywood;
}
</style>
