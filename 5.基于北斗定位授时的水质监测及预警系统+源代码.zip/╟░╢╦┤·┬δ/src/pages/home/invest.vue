<template>
  <div>
    <el-card class="one1">
      <div ref="one" class="one2"></div>
      <div ref="myechart" class="one3"></div>
      <div  class="one4">
      <litable :tableData="tableData" :tableKey="investKey"></litable>
      </div>
    </el-card>

  </div>
</template>

<script>
import Litable from '../../components/litable.vue'
import {investKey,tableData} from '@/pages/home/equipment/managejs/maneages.js'
export default {
  components: {
    Litable,
  },
  data() {
    return {
      investKey,

      text:'答辩的光伏设备电功率具体信息',
      time:['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      tableData,
      clickone: '',
      clickone2:[820, 932, 901, 934, 1290, 1330, 1320],
      one1x: [0, 0.01],
      one1y: ['无', '无', '无', '答辩的光伏设备', '光伏设备-1号'],
      one1_data_1: [0,0,0,48, 10],
      one1_data_2: [0,0,0,50, 34],
      one1_data_3: [0,0,0,30, 18],
      one1_data_4: [0,0,0,22, 16],
    }
  },
  mounted() {
    this.initDate()
    this.initData2()
  },
  watch: {
    clickone(val) {
      console.log('点击函数改变展示', val)
    },
  },
  methods: {
    // 总电量对比图
    initDate() {
      var container = this.$echarts.init(this.$refs.one)
      var option = {
        title: {
          text: '电功率排名前五',
          left:'center',
          textStyle:{
            // title样式
          }
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'shadow',
          },
        },
        legend: {
          top:'92%',
        },
        grid: {
          left: '1%',
          right: '1.5%',
          bottom: '10%',
          containLabel: true,
        },
        xAxis: {
          type: 'value',
          boundaryGap: this.one1x,
        },
        yAxis: {
          type: 'category',
          data: this.one1y,
        },
        series: [
          {
            stack: 'total',
            name: '第一季度电功率',
            type: 'bar',
            data: this.one1_data_1,
          },
          {
            stack: 'total',
            name: '第二季度电功率',
            type: 'bar',
            data: this.one1_data_2,
          },
          {
            stack: 'total',
            name: '第三季度电功率',
            type: 'bar',
            data: this.one1_data_3,
          },
          {
            stack: 'total',
            name: '第四季度电功率',
            type: 'bar',
            data: this.one1_data_4,
          },
        ],
      }
      container.setOption(option)
      container.on('click', (params) => {
        this.clickone = params.name
        console.log('一整行数据', params.name)
      })
      // container.getZr().on('click', params=>{
      //   let pointInPixel = [params.offsetX, params.offsetY]

      //   console.log('一整行数据',pointInPixel,params,params.seriesIndex,params.name);
      // })
    },
    // 详情信息
    initData2() {
      var myChart = this.$echarts.init(this.$refs.myechart)
      var option = {
        title: {
          text: this.text,
        },
        legend: {
          data: ['电功率'],
        },
        tooltip: {
          trigger: 'axis',
        },
        xAxis: {
          name: '电功率',
          boundaryGap: false,
          type: 'category',
          data: this.time,
        },
        yAxis: {
          type: 'value',
        },
        series: [
          {
            name: '电功率',
            data: this.clickone2,
            type: 'line',
            smooth: true,
          },
        ],
      }
      myChart.setOption(option)
    },
  },
}
</script>

<style lang="less" scoped>
@import '@/pages/home/equipment/manageCss/invest.less';
</style>
