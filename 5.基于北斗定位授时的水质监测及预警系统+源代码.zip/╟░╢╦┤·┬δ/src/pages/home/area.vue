<template>
  <div>
    <!-- 图标1跳转 -->
    <el-card style="margin-left: 20px">
      <el-row>
        <el-button type="primary" icon="el-icon-s-data" style="margin-left: 200px" circle></el-button>
        <el-button type="success" icon="el-icon-location" style="margin-left: 250px" circle></el-button>
        <el-button type="info" icon="el-icon-s-grid" style="margin-left: 300px" circle></el-button>
        <el-button type="warning" icon="el-icon-thumb" style="margin-left: 350px" circle></el-button>
      </el-row>
    </el-card>

    <!-- 机器分布 -->
    <div v-for="equi in list" :key="equi.index">
      <el-col span="8">
        <el-card style="
            width: 350px;
            height: 360px;
            margin-left: 20px;
            margin-top: 60px;
          ">
          {{ equi.lable }}
          <el-divider></el-divider>
          <baidu-map :center="equi.center" :zoom="equi.zoom" style="height:300px; width: 100%" :scroll-wheel-zoom="true">
            <bm-marker :position="equi.position" :dragging="true">
              <!-- <bm-info-window :show="show" @close="infoWindowClose" @open="infoWindowOpen">吉首大学后山</bm-info-window> -->
            </bm-marker>
          </baidu-map>
        </el-card>
      </el-col>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      list: [
        {
          lable: 'XX大学XX校区',
          zoom: 14,
          center: {
            lng: 109.72665356961592,
            lat: 28.29607849022124,
          },
          position:{
            lng: 109.72665356961592,
            lat: 28.29607849022124,
          }
        },
        // {
        //   lable: 'XX古城',
        //   // url: require('../../page/lightpage.png') 
        // },
        // {
        //   lable: 'XX大学',
        //   // url: require('../../page/lightpage1.png'),
        // },
        // {
        //   lable: 'XX大学XXX校区',
        //   // url: require('../../page/lightpage.png'),
        // },
      ],
    }
  },
  methods: {
    clickmanage() {
      this.$router.push('/manage')
    },
  },
}
</script>

<style></style>
