<template>
  <div>
    <!-- 1.地图 -->
    <el-card>
      <div class="message-left">
        <litable
          :tableData="tableData"
          :tableKey="tableKey"
          border
          class="message-left1"
        ></litable>
        <div class="hintleft">
          <el-switch
            v-model="value1"
            active-text="开关1开"
            inactive-text="开关1关"
            class="awitch1"
          >
          </el-switch>
          <p>
          <el-switch
            v-model="value3"
            active-text="开关2开"
            inactive-text="开关2关"
            class="awitch2"
          >
          </el-switch>
          </p>
        </div>
        <div class="hint">
          <p v-for="(item,index) in derailList" :key="index" style="margin-top:8%">
            <b>{{item.label}}&emsp;:</b>
            <span style="float: right">
              {{detail[item.name]}}
            </span>
          </p>
        </div>
      </div>
      <div class="map-right">
        <baidu-map
          :center="center"
          :zoom="zoom"
          class="Limapcard"
          :scroll-wheel-zoom="true"
        >
          <bm-marker
            :position="position"
            :dragging="true"
            @click="infoWindowOpen"
          >
            <!-- <bm-info-window
              :show="show"
              @close="infoWindowClose"
              @open="infoWindowOpen"
              >吉首大学后山</bm-info-window
            > -->
          </bm-marker>
        </baidu-map>
      </div>
    </el-card>

    <!-- 2.设备数据 -->
    <div>
      <el-card class="mapMessage">
        <!-- 2.日期选择器 -->
        <div class="block">
          <span class="demonstration" style="margin-right: 2%"
            >查看数据时间段</span
          >
          <!-- datetimerange有时分秒 daterange无 -->
          <el-date-picker
            v-model="value2"
            type="daterange"
            align="right"
            unlink-panels
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :picker-options="pickerOptions"
            value-format="yyyy-MM-dd"
          >
          </el-date-picker>
          <el-button @click="newclick">最近数据</el-button>
          <el-button @click="flushclick">所有数据</el-button>
        </div>
        <el-divider></el-divider>
        <!-- 2.左 线型图 -->
        <div ref="myechart" class="map-left"></div>
        <!-- 2.右 设备详情 -->
        <div class="message-right">
          <span> 设备详情 </span>
          <span style="float: right"> 设备状态 </span>
          <div>
            <div ref="circle1" class="message1"></div>
          </div>
          <div class="average">
            <p class="average1">平均温度:{{ this.temperature }}°</p>
            <p class="average1">平均功率:{{ this.averagePower }}kW·h</p>
            <p class="average1">平均湿度:{{ this.generating1 }}%rh</p>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 3.设备历史数据 -->
    <el-card class="DataCard">
      <span> 设备历史数据 </span>
      <el-divider></el-divider>
      <div class="LILI">
        <div ref="containerr" class="LiID"></div>
      </div>
    </el-card>
  </div>
</template>

<script>
import litable from '@/components/litable'
import {
  tableKey,
  tablekey1,
  derailList,
} from '@/pages/home/equipment/managejs/maneages.js'
import api from 'api'
import moment from 'moment'
import echarts from 'echarts'
export default {
  components: {
    litable,
  },
  data() {
    return {
      detail:'',
      value1: true,
      value3: true,
      tableData: [],
      tableData1: [],
      tableKey,
      tablekey1,
      derailList,
      // 定时器
      timer: null,
      dataCount: [],
      // 日期
      timevalue: '',
      //日期选择器
      pickerOptions: {
        shortcuts: [
          {
            text: '最近一周',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近一个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 30)
              picker.$emit('pick', [start, end])
            },
          },
          {
            text: '最近三个月',
            onClick(picker) {
              const end = new Date()
              const start = new Date()
              start.setTime(start.getTime() - 3600 * 1000 * 24 * 90)
              picker.$emit('pick', [start, end])
            },
          },
        ],
      },
      timeDataL: [],
      value2: [],
      // 设备详情
      temperature: 0,
      averagePower: 0,
      generating1: 0,
      // 设备ID
      userdeviceId: 0,
      // 地图
      show: false,
      center: {
        lng: 109,
        lat: 29,
      },
      position: {
        lng: 109,
        lat: 29,
      },
      zoom: 16,
      // 折线图
      eleData: [],
      timeData: [],
      TemData: [],
      humData: [],
      // 电功率的时间
      measureTime1: '',
      measureTime2: '',
    }
  },

  watch: {
    eleData() {
      this.setChart()
    },
    timeData() {
      this.setChart()
    },
    dataCount() {
      this.initDate()
    },
    value2() {
      if (this.value2 == null) {
        this.setMeasureTime()
        this.showFlash()
        this.queryExtraDataL()
      } else {
        this.setMeasureTime()
        clearInterval(this.timer)
        this.queryPowerL()
        this.queryExtraDataL()
      }
    },
  },

  mounted() {
    this.setChart()
    this.maplan()
    // this.hiadata()
    this.initDate()
    this.circleMessage()
    this.details()
  },

  created() {
    this.queryPDataCount()
    // this.firstTime()
    this.queryPowerL()
    this.queryExtraDataL()
    this.showFlash()
    this.message()
  },

  methods: {   
    showFlash() {
      this.timer = setInterval(() => {
        this.queryPowerL()
        this.queryExtraDataL()
        this.circleMessage()
      }, 2500)
    },
    showNow() {
      this.timer = setInterval(() => {
        this.getNowPower()
        // this.queryExtraDataL()
        this.circleMessage()
      }, 1500)
    },
    async details(){
      const data = await api.queryDeviceDetails.queryDeviceDetails({
        usrId: window.localStorage.getItem('userId'),
        deviceId:parseInt(this.$route.query.userdeviceId)
      })
      this.detail = data.data
    },
    newclick(){
      clearInterval(this.timer)
      this.firstTime()
      this.showNow()
      // this.queryExtraDataL()
    },
    flushclick(){
      this.showFlash()
      this.queryExtraDataL()
    },
    setMeasureTime() {
      if (this.value2 == null) {
        this.measureTime1 = ''
        this.measureTime2 = ''
        console.log('11111111');
      } else {
        this.measureTime1 = this.value2[0]
        this.measureTime2 = this.value2[1]
      }
    },

    // 地图图标
    infoWindowOpen() {
      this.show = true
    },
    infoWindowClose() {
      this.show = false
    },
    // 日期
    initDate() {
      var container = this.$echarts.init(this.$refs.containerr)
      var option = {
        // 显示值
        tooltip: {
          trigger: 'item',
          position: 'top',
          // 显示日期
          formatter: function(p) {
            var format = echarts.format.formatTime('yyyy-MM-dd', p.data[0])
            return format + ' 数据收集次数为' + p.data[1] + '次'
          },
        },
        visualMap: {
          // 进度条
          // type: 'piecewise',
          // orient: 'horizontal',

          // 进度
          show: false,
          min: 0,
          max: 50,
          // 改变表格颜色
          inRange: {
            color: ['#F0FFFF', '#409EFF'],
            // 颜色深浅度
            opacity: 1,
          },
        },

        // 这里面可以改变样式
        calendar: [
          // 确定表格那一年
          {
            // 必须要有年份
            range: [this.timeget(1), this.timeget(2)],
            left: 80,
            right: 40,
            // 设置月份分割线的颜色
            splitLine: {
              show: true,
              lineStyle: {
                color: '#D3D3D3',
                width: 4,
                type: 'solid',
              },
            },
          },
        ],

        series: [
          {
            // scatter 变成点
            type: 'heatmap',
            coordinateSystem: 'calendar',
            calendarIndex: 0,
            data: this.dataCount,
          },
        ],
      }
      container.setOption(option)

      var that = this

      container.on('click', function(p) {
        that.one(p.data[0])
      })
    },
    one(val) {
      this.measureTime1 = val
      val = new Date(val)
      let dateTemp = val.setDate(val.getDate() + 1)
      let time = new Date(dateTemp)
      this.measureTime2 = echarts.format.formatTime('yyyy-MM-dd', time)
      this.queryPowerL()
      this.queryExtraDataL()
      clearInterval(this.timer)
    },

    initDateTime(time) {
      this.measureTime1 = time
    },

    timeget(yy) {
      const bb = new Date()
      if (yy == 1) bb.setFullYear(bb.getFullYear() - 1)
      var starttime =
        bb.getFullYear() + '-' + (bb.getMonth() + 1) + '-' + bb.getDate()
      console.log('去年的时间是', starttime)
      return starttime
    },

    async queryPDataCount() {
      const count = await api.queryPDataCount.queryPDataCount(
        this.$route.query.userdeviceId
      )
      this.dataCount = count.data.PowerDataCount
    }, //发送请求查询该日期之前一年内的数据

    //经纬度
    async maplan() {
      const data3 = await api.queryLocate.queryLocate(
        parseInt(this.$route.query.userdeviceId)
      )
      this.center.lat = data3.data.latitude
      this.center.lng = data3.data.longitude
      this.position.lat = data3.data.latitude
      this.position.lng = data3.data.longitude
    },
    firstTime(){
      let date = new Date();
      date = moment(date).format('YYYY-MM-DD HH:mm:ss')
      this.measureTime1 = date
      this.measureTime2 = null
      console.log('时间',this.measureTime1);
    },
    // 电能
    async queryPowerL() {
      const data1 = await api.queryPower.queryPower({
        deviceId: parseInt(this.$route.query.userdeviceId),
        measureTime1: this.measureTime1,
        measureTime2: this.measureTime2,
      })
      this.eleData = []
      this.timeData = []
      for (let i = 0; i < data1.data.mainData.length; i++) {
        this.eleData.push(data1.data.mainData[i].electricityPower)
        data1.data.mainData[i].measureTime = moment(
          data1.data.mainData[i].measureTime
        ).format('YYYY-MM-DD HH:mm:ss')
        this.timeData.push(data1.data.mainData[i].measureTime)
      }

      this.averagePower = data1.data.averagePower.toFixed(2)
    },
    
    async getNowPower() {
      console.log(parseInt(this.$route.query.userdeviceId));
      console.log("----------->", this.measureTime1);
      const data1 = await api.queryNowPower.queryNowPower({
        deviceId: parseInt(this.$route.query.userdeviceId),
        measureTime1: this.measureTime1,
        measureTime2: this.measureTime2,
      })
      this.eleData = []
      this.timeData = []
      for (let i = 0; i < data1.data.mainData.length; i++) {
        this.eleData.push(data1.data.mainData[i].electricityPower)
        data1.data.mainData[i].measureTime = moment(
          data1.data.mainData[i].measureTime
        ).format('YYYY-MM-DD HH:mm:ss')
        this.timeData.push(data1.data.mainData[i].measureTime)
      }

      this.averagePower = data1.data.averagePower.toFixed(2)
    },
    // 温湿度
    async queryExtraDataL() {
      const data2 = await api.queryExtraData.queryExtraData({
        deviceId: parseInt(this.$route.query.userdeviceId),
        measureTime1: this.measureTime1,
        measureTime2: this.measureTime2,
      })
      this.TemData = []
      this.humData = []
      this.timeDataL = []
      for (let i = 0; i < data2.data.extraData.length; i++) {
        this.TemData.push(data2.data.extraData[i].dataTemperature)
        // 湿度
        this.humData.push(data2.data.extraData[i].dataHumidity)
        this.timeDataL.push(data2.data.extraData[i].measureTime)
      }
      this.temperature = data2.data.averageTemperature.toFixed(2)
      this.generating1 = data2.data.averageHumidity.toFixed(2)
    },

    setChart() {
      var myChart = this.$echarts.init(this.$refs.myechart)

      var option = {
        legend: {
          data: ['光能数据', '湿度', '温度'],
        },
        tooltip: {
          trigger: 'axis',
          formatter: function (c) {
            let str = '';
            c.forEach((item)=>{
              let temp = {}
              if(item.seriesName == '光能数据'){
                temp.format = 'W'
              }else if(item.seriesName == '湿度'){
                temp.format = '%rh'
              }else{
                temp.format = '°'
              }
              temp.value = item.value
              temp.seriesName = item.seriesName
              str += temp.seriesName+': '+temp.value + ' '+temp.format+'<br />'
            })
            return str
          }
        },
        grid:{
          left: '8%',
          right: '12%',
          bottom: '10%',
        },
        xAxis: [
          {
            type: 'category',
            boundaryGap: false,
            data: this.timeData,
          },
        ],
        yAxis: [{
          type: 'value',
          position: 'left',
          name: '光能数据',
        },
        {
          type: 'value',
          position: 'right',
          name: '湿度',
          splitLine: { //网格线
              show: false
          }
        },
        {
          type: 'value',
          position: 'right',
          name: '温度',
          offset: 60,
          splitLine: { //网格线
              show: false
          }
        }
        ],
        series: [
          {
            name: '光能数据',
            data: this.eleData,
            yAxisIndex: 0,
            type: 'line',
          },
          {
            name: '湿度',
            data: this.humData,
            yAxisIndex: 1,
            type: 'line',
          },
          {
            name: '温度',
            // 后一个系列会在前一个系列相加
            // stack: 'Total',
            data: this.TemData,
            yAxisIndex: 2,
            type: 'line',
          },
        ],
      }
      console.log(option)
      myChart.setOption(option)
    },

    // 平均温度湿度功率
    circleMessage() {
      var circleMessage1 = this.$echarts.init(this.$refs.circle1)

      var option = {
        // 悬停提示框
        tooltip: {
          trigger: 'item',
          formatter: function(p) {
            return '详情:' + p.data.name + p.data.value
          },
        },
        legend: {
          bottom: '1%',
          left: 'center',
        },
        series: [
          {
            name: 'Access From',
            type: 'pie',
            // 内外圆半径
            // radius: ['40%', '70%'],
            avoidLabelOverlap: false,
            label: {
              show: false,
              // position: 'center',
            },
            emphasis: {
              label: {
                show: false,
                fontSize: '30',
                fontWeight: 'bold',
              },
            },
            labelLine: {
              show: false,
            },
            data: [
              { value: this.temperature, name: '平均温度' },
              { value: this.generating1, name: '平均湿度' },
              { value: this.averagePower, name: '平均电能' },
            ],
          },
        ],
      }
      circleMessage1.setOption(option)
    },

    // 基础信息
    async message() {
      const data = await api.workParameters.workParameters(
        window.localStorage.getItem('userId')
      )
      this.tableData = [
        {
          device_id: data.data.device_id,
          operating_hours: data.data.operating_hours,
          temperature: data.data.temperature,
          battery: data.data.battery,
        },
      ]
      this.tableData1 = [{ battery: data.data.battery }]
    },
  },

  beforeDestroy() {
    clearInterval(this.timer)
  },
}
</script>

<style lang="less" scoped>
@import '@/pages/home/equipment/manageCss/maneage.less';
</style>
