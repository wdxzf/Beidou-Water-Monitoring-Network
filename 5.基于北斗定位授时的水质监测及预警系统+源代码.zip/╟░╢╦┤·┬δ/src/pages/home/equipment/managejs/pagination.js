export function pagination (lists,pagSize,page) {
  let num = (page-1) * pagSize
  return lists.slice(num,num+pagSize)
}