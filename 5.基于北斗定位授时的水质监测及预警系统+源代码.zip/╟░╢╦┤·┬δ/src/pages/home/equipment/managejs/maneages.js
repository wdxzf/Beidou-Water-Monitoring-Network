const testList=[
  {
    id:1,
    name:'设备名称1',
    eui:'12346',
    address:"xx大学土木工地",
    type:'土木类',
    longitude:'29.5°',//经度
    latitude:'125.4°',//纬度
    creatData:'2020-09-03',
  },
  {
    id:2,
    name:"设备名称2",
    eui:'12347',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  },
  {
    id:3,
    name:"设备名称3",
    eui:'12348',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  },
  {
    id:4,
    name:"设备名称4",
    eui:'12345',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  },
  {
    id:5,
    name:"设备名称5",
    eui:'55555',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  },
  {
    id:6,
    name:"设备名称6",
    eui:'66666',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  },
  {
    id:7,
    name:"设备名称7",
    eui:'67777',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  },
  {
    id:8,
    name:"设备名称8",
    eui:'6888',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  },
  {
    id:9,
    name:"设备名称9",
    eui:'9999',
    address:'',
    type:'',
    longitude:'',//经度
    latitude:'',//纬度
    creatData:'',
  }
]


const tableKey= [
  { name: "设备Id", value: "device_id" },
  { name: "工作时间/h", value: "operating_hours" },
  { name: "设备温度/°", value: "temperature" },
  { name: "开关电池量/%", value: "battery"}
]
const tablekey1 = [
  {name:"开关电源", value:"battery"},
  {name:"开关一", value:""},
  {name:"开关一", value:""},
  {name:"开关一", value:""},
]
const investKey = [
  {name:'设备名称',value:'aa'},
  {name:'设备地址',value:'bb'},
  {name:'添加时间',value:'cc'},
  {name:'平均发电率',value:'dd'},
  { name: "设备温度", value: 'ff' },
  { name: "工作时间/h", value: 'ee' },
]
const derailList = [
  {label:'设备名称' , name:'deviceName'},
  {label:'地理位置' , name:'deviceAddres'},
  {label:'创建时间' , name:'createDate'},
]
const tableData = [
  {aa:'光伏设备-1号',bb:'XX大学工科楼',cc:'2021-10-08',dd:'1060W·h',ee:'91h',ff:'正常'},
  {aa:'答辩的光伏设备',bb:'XX大学',cc:'2021-10-18',dd:'2160W·h',ee:'1h',ff:'正常'},
]
export {
  testList,
  tableKey,
  tablekey1,
  investKey,
  derailList,
  tableData,
}