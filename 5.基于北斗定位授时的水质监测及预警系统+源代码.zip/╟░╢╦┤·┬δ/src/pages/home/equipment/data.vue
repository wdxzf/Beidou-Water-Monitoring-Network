<template>
  <div>

    <el-card class="query">
      <el-input class="queryId" placeholder="请输入设备名称..." prefix-icon="el-icon-search" v-model="fixingname">
        <el-button slot="append" icon="el-icon-search" @click="clickneme(fixingname)"></el-button>
      </el-input>
    </el-card>

    <el-card class="deviceId">
      <!-- <el-row> -->
        <el-col :span="6" v-for="(o,index) in tableData" :key="index">
          <el-card shadow="hover" class="deviceStyle">
            <span slot="header">
              <span>设备ID：{{o.deviceId}}</span>
                <el-button class="btn"  size="mini" @click="equipment(o)">详细信息</el-button>
              <p>设备名称：{{o.deviceName}}</p>
            </span>
            <span>
              <i class="el-icon-s-data" style="font-size:120px;float:left"></i>
            </span>
            <span style="float:right;font-size:18px">
              <p>设备EUI：{{o.deviceEui}}</p>
              <p>创建时间:{{o.createDate}}</p>
            </span>
          </el-card>
        </el-col>
      <!-- </el-row> -->
    </el-card>
  </div>

</template>

<script>
import api from 'api'
export default {
  data() {
    return {
      fixingname: '',
      // TopicTypeId:'',
      tableData: [
        {
          deviceId: 1 ,
          deviceName: '',
          deviceEui: '',
          createDate: '',
        },
      ],
    }
  },
  mounted(){
    this.look()
  },
  methods: {
     async clickneme(val) {
      const data = await api.queryDeviceList.queryDeviceList({
        addressId:'',
        deviceName:val,
        userId:window.localStorage.getItem('userId'),
      })
      this.tableData = data.data
    },
    async look(){
      const data = await api.queryDeviceList.queryDeviceList({
        userId:window.localStorage.getItem('userId'),
      })
      this.tableData = data.data
      console.log('设备',this.tableData);
    },
    equipment(val) {
      this.$router.push({
        path: 'equipment',
        // query名称自定义
        query:{
          userdeviceId:val.deviceId
        }
      })
    }
  }
}
</script>

<style lang="less" scoped>
@import '@/pages/home/equipment/manageCss/data.less';
</style>
