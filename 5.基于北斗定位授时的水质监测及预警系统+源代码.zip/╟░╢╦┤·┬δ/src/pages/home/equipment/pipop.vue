<template>
  <div>
    <el-dialog :visible.sync="dialogVisible" :title="title" @close="closeDialog">
      <el-form :model='device' :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="设备名称" prop="name">
          <el-input type="text" v-model="device.name" placeholder="请输入名称" ></el-input>
        </el-form-item>
        <el-form-item label="设备EUI" prop="eui">
          <el-input type="text" v-model="device.eui" placeholder="请输入8位16进制的EUI编号"></el-input>
        </el-form-item>
        <el-form-item label="设备类型">
          <el-input type="text" v-model="device.type" placeholder="请输入类型"></el-input>
        </el-form-item>
        <el-form-item label="设备地区" prop="addressId">
<!--          <el-input type="text" v-model="device.address" placeholder="请输入位置"></el-input>-->
          <el-cascader :props="props" style="width: 100%" v-model="device.addressId"></el-cascader>
        </el-form-item>
        <el-form-item label="详细地址" prop="address">
          <el-input type="text" v-model="device.address" placeholder="请输入详细地址"></el-input>
        </el-form-item>
        <el-form-item label="安装倾角" prop="angle">
          <el-input type="text" v-model="device.angle" placeholder="请输入安装倾角"></el-input>
        </el-form-item>
        <el-form-item label="规格大小" >
          <el-input type="text"  v-model="device.specification" placeholder="请输入设备规格"></el-input>
        </el-form-item>
        <el-form-item label="标准电压" prop="voltag">
          <el-input type="text" onkeyup="value=value.replace(/[^\d]/g,'')" v-model="device.voltag" placeholder="请输入标准电压"></el-input>
        </el-form-item>
        <el-form-item label="标准功率" prop="power">
          <el-input type="text" onkeyup="value=value.replace(/[^\d]/g,'')" v-model="device.power" placeholder="请输入设备功率"></el-input>
        </el-form-item>
        <el-form-item label="有效半径" prop="range">
          <el-input type="text" onkeyup="value=value.replace(/[^\d]/g,'')" v-model="device.range" placeholder="请输入半径"></el-input>
        </el-form-item>
        <el-form-item label="设备备注">
          <el-input type="text" v-model="device.mark" placeholder="备注"></el-input>
        </el-form-item>
      </el-form>
      <el-button type="primary" round @click="Ok('ruleForm')" style="margin-left: 45%">确认</el-button>
      <el-button type="primarys" round @click="Cancel('ruleForm')">重置</el-button>
    </el-dialog>
  </div>
</template>


<script>
  import api from 'api'
export default {
  props: ['equipdialogVisible','buttonType','deviceInfo'],
  data() {
    return {
      dialogVisible: false,
      titles: ['添加设备', '修改设备'],
      title:'',
      addressInfo: [],
      device: {
        name: '',
        eui: '',
        address: '',
        type: '',
        angle: '',
        specification: '',
        voltag: '',
        power: '',
        range: '',
        mark: '',
        addressId:[],
      },
      rules: {
        name: [
          {type:'string', required: true, message: '请输入名称', trigger: 'blur'}
        ],
        eui: [
          {type:'string', required: true, message: '请输入16进制8位eui编号', trigger: 'blur'}
        ],
        address: [
          {required: true, message: '请填写详细地址', trigger: 'blur'}
        ],
        addressId:[
          {required: true, message: '请选择地区', trigger: 'blur'}
        ],
        // angle: [
        //   { type: 'integer', min: 0, max: 360, message: '请输入数字' ,trigger: 'change' }
        // ],
        // voltag:[
        //   { type: 'number' ,message: '请输入数字'}
        // ],
        // power:[
        //   { type: 'number' ,message: '请输入数字'}
        // ],
        // range: [
        //   { type: 'number' ,message: '请输入数字'}
        // ]
      },
      props: {
        label: 'cityname',
        value: 'id',
        lazy: true,
        async lazyLoad(node, resolve) {
          if (node.level > 2) {
            resolve(null)
            return
          }
          let data
          console.log("0-------0")
          if (node.level == 0) {
            data = await api.getAddress.getAddress(1)
          } else {
            data = await api.getAddress.getAddress(JSON.stringify(node.data.id))
          }
          if (data.code == 200 && data.data.length > 0) {
            resolve(data.data)
          } else {
            resolve()
          }
        }
      }
    }
  },
  mounted() {

  },
  watch:{
    equipdialogVisible(v){
      this.dialogVisible = v
    },
    buttonType(v){
      this.title = v<0?this.titles[0]:this.titles[1];
      console.log(this.deviceInfo[v],'---this.deviceInfo[v]---')
      if(v>=0){
        this.device.name=this.deviceInfo[v].deviceName;
        this.device.eui=this.deviceInfo[v].deviceEui;
        this.device.address=this.deviceInfo[v].address[this.deviceInfo[v].address.length-1];
        this.device.type=this.deviceInfo[v].deviceType;
        this.device.angle=this.deviceInfo[v].deviceAngle;
        this.device.specification=this.deviceInfo[v].deviceSpecification;
        this.device.voltag=this.deviceInfo[v].deviceVoltag;
        this.device.power=this.deviceInfo[v].devicePower;
        this.device.range=this.deviceInfo[v].deviceRange;
        this.device.mark=this.deviceInfo[v].deviceMark;
        this.device.addressId=this.deviceInfo[v].addressId;
      }else {
        Object.keys(this.device).forEach((key)=>this.device[key] = '')
      }
    }
  },
  methods:{
    Ok(formName){
      this.$refs[formName].validate(async (valid) => {
        if(valid) {
          console.log(this.device.name);
          let data
          if(this.buttonType<0)
          {
            data = await api.addDevice.addDevice({
              'userId':1,
              'deviceInfo':{
                'deviceName':this.device.name,
                'deviceEui':this.device.eui,
                'deviceAddres':this.device.address,
                'deviceType':this.device.type,
                'deviceAngle':this.device.angle,
                'deviceSpecification':this.device.specification,
                'deviceVoltag':parseInt(this.device.voltag),
                'devicePower':parseInt(this.device.power),
                'deviceRange':parseInt(this.device.range),
                'deviceMark':this.device.mark,
                'addressId':parseInt(this.device.addressId[this.device.addressId.length-1]),
              }
            })
          }else {
            data = await api.updateDeviceInfo.updateDeviceInfo({
                'deviceId':this.deviceInfo[this.buttonType].deviceId,
                'deviceName':this.device.name,
                'deviceEui':this.device.eui,
                'deviceAddres':this.device.address,
                'deviceType':this.device.type,
                'deviceAngle':this.device.angle,
                'deviceSpecification':this.device.specification,
                'deviceVoltag':parseInt(this.device.voltag),
                'devicePower':parseInt(this.device.power),
                'deviceRange':parseInt(this.device.range),
                'deviceMark':this.device.mark,
                'addressId':parseInt(this.device.addressId[this.device.addressId.length-1]),
            })
          }
          console.log(data);
          if(data.code == 200){
            this.$message("设备添加成功！")
            this.$emit("addSeviceSuccess")
          }else{
            this.$message.error("设备添加失败！"+data.message)
          }
          this.$emit("update:equipdialogVisible",false)
          this.dialogVisible = false
          return true
        }else {
          this.$message.error("信息填写不完全")
          return false
        }
      });
    },
    Cancel(formName){
      this.$refs[formName].resetFields();
      Object.keys(this.device).forEach((key)=>this.device[key] = '')
    },
    closeDialog(){
      this.$emit("update:equipdialogVisible",false)
    }
  }
}
</script>