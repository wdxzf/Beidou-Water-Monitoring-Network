<template>
  <div style="height: 100%">
    <el-card>
      <el-input style="width: 30%;" placeholder="请输入设备名称..." prefix-icon="el-icon-search" v-model="managename">
        <el-cascader :props="props" slot="prepend" v-model="searchAddrss" style="width: 150px"></el-cascader>
        <el-button slot="append" icon="el-icon-search" @click="getDeviceList"></el-button>
      </el-input>
      <el-button type="primary" style="margin-left:30px" icon="el-icon-plus" @click="deviceDialog(-1)">添加设备</el-button>
<!--      <el-button type="success" style="margin-left:30px" icon="el-icon-edit" @click="deviceDialog(1)">编辑设备</el-button>-->
      <el-button type="danger" style="margin-left:30px" icon="el-icon-delete" @click="deleteDevice">删除设备</el-button>
      <pipop
      :equipdialogVisible.sync='dialogVisible'
      :buttonType="buttonType"
      :deviceInfo="testLists"
      @addSeviceSuccess="addDeviceSuccess"
      >
      </pipop>
    </el-card>
<!--设备列表-->
    <el-row style="background-color: #fff">
      <el-checkbox :indeterminate="isIndeterminate"  v-model="checkAll" @change="handleCheckAllChange" style="margin-left: 3%;margin-top: 1%">全选</el-checkbox>
    </el-row>
    <div class="tableList">
      <el-row :gutter="20" style="height: 80%">
        <el-checkbox-group style="height: 100%;font-size: large" v-model="checkList" @change="handleCheckedCitiesChange">
          <el-col v-for="(item,index) in curTable" :key="item.deviceId" :span="6" style="height: 45%;margin-top: 2%;">
            <div class="tableList_card">
              <el-checkbox :label="item.deviceId" style="float: left;left: 1%;"><pre>&nbsp;</pre></el-checkbox>
              <i class="el-icon-s-platform tableList_card_i" @click="deviceDialog(index)"></i>
              <div style="float: right; width: 60%">
                <p class="tableList_card_p"><i class="el-icon-cpu"></i>设备名称：{{item.deviceName}}</p>
                <p class="tableList_card_p"><i class="el-icon-s-help"></i>设备EUI：{{item.deviceEui}}</p>
                <p class="tableList_card_p" ><i class="el-icon-location"></i>设备地址：{{item.address.join('-')}}</p>
                <p class="tableList_card_p" ><i class="el-icon-connection"></i>添加时间：{{item.createDate}}</p>
                <p class="tableList_card_p"><i class="el-icon-connection"></i>设备备注：{{item.deviceMark}}</p>
              </div>
            </div>
          </el-col>
        </el-checkbox-group>
      </el-row>
<!--      //分页-->
      <el-divider></el-divider>
      <div class="pagination">
        <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current-page="curPag"
                :page-sizes=pageSizes
                :page-size=pageSize
                layout="total, sizes, prev, pager, next, jumper"
                :total="totalNum">
        </el-pagination>
      </div>
    </div>

  </div>
</template>

<script>
import pipop from '@/pages/home/equipment/pipop'
//import { testList } from './managejs/maneages.js'
import { pagination } from './managejs/pagination.js'
import api from 'api'
export default {
  components:{
    pipop
  },
  data(){
    return {
      managename:'',
      // 弹框
      dialogVisible:false,
      buttonType:-1,//添加、编辑标记
      checkList:[],//多选组
      pageSizes:[8,12,16],
      pageSize:8,//当前分页
      curPag:1,//当前页
      testLists:[],//所有设备列表
      curList:[],//当前页面列表
      searchSelect:[],//
      searchAddrss:-1,//查询地区
      checkAll: false,//全选标记
      isIndeterminate: false,//全选图形
      props: {
        label: 'cityname',
        value: 'id',
        lazy: true,
        async lazyLoad(node, resolve) {
          if(node.level > 2) {
            resolve(null)
            return
          }
          let data
          console.log("0-------0")
          if(node.level==0){
            data = await api.getAddress.getAddress(1)
          }else {
            data = await api.getAddress.getAddress(JSON.stringify(node.data.id))
          }
          if(data.code == 200 && data.data.length > 0) {
            resolve(data.data)
          }else {
            resolve()
          }
        }
      },
    }
  },
  created(){
    this.getDeviceList()
    //this.testLists = testList
    //const data = api.getAddress.getAddress(1)
    //console.log(data)
  },
  computed: {
    curTable(){
      return pagination(this.testLists,this.pageSize,this.curPag);
    },
    totalNum(){
      console.log(this.testLists.length)
      return this.testLists.length
    }
  }
  ,
  methods:{
    //获取设备列表
    async getDeviceList(){
      let address = ''
      if(this.searchAddrss.length>0)
      address = this.searchAddrss[this.searchAddrss.length-1]
      const data = await api.getDeviceList.getDeviceList({
        userId:1,
        deviceName:this.managename,
        addressId:address
      })
      if(data.code == 200){
        this.testLists = data.data
      }
    },
    async deleteDevice(){
      const data = await api.deleteDevice.deteleDevice(this.checkList)
      if(data.code == 200){
        this.$message.success("删除成功！")
      }else {
        this.$message.error("删除失败！")
      }
      this.getDeviceList()
    },
    // 弹框
    deviceDialog(val){
      this.buttonType = val
      console.log('this.dialogVisible',this.dialogVisible);
      this.dialogVisible = true;
    },
    handleSizeChange(val){
      this.pageSize = val
    },
    //换页
    handleCurrentChange(val){
      this.curPag = val
      this.checkList = []
      this.checkAll = false
    },
    //全选
    handleCheckAllChange(val) {
      this.curList = pagination(this.testLists,this.pageSize,this.curPag);
      if(val){
        for(let i in this.curList){
          this.checkList.push(this.curList[i].id)
        }
      }else{
        this.checkList = []
      }
      this.isIndeterminate = false;
    },
    //单选组
    handleCheckedCitiesChange(value) {
      console.log(value,'---value---')
      this.curList = pagination(this.testLists,this.pageSize,this.curPag);
      let checkedCount = value.length;
      this.checkAll = checkedCount === this.curList.length;
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.curList.length;
    },
    //添加设备事件
    addDeviceSuccess(){
      this.getDeviceList()
    }
  }
}
</script>
<style>
  .tableList {
    /* height: 100%; */
    width: 100%;
    background-color: #fff;
  }
  .tableList_card {
    margin-left: 2%;
    height: 500px;
    width: 100%;
    color: #000;
    background-color: #edede7;
    border-radius: 15px;
    padding: 1px;
    box-shadow: 5px 10px 5px #999;
  }
  .tableList_card_i {
    font-size: 600%;
    float: left;
    margin-top: 30%;
  }
  .tableList_card_p {
    border-bottom: 1px solid #000000;
    border-radius: 15px;
    width: 100%;
    margin-top: 10%;
    display:inline-block;
    font-size: 15px;
    word-wrap: break-word;
    word-break: break-all;
  }
  .pagination {
    height: 100px;
    width: 5%;
    margin-left: 3%;
  }
</style>