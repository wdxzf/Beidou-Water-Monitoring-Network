<template>
  <!-- 页面主题区域 -->
  <el-container class="home-container">
    <!-- 侧边栏 -->
    <el-aside :width="isCollapse ? '64px' : '220px'">
      <div class="toggle-student">
        <i class="el-icon-bangzhu"></i>
        <span>{{ systemName }}</span>
      </div>
      <div class="toggle-button" @click="toggleCollapse">|||</div>
      <!-- 侧边栏菜单栏效果 -->

      <com-aside :isCollapse="isCollapse"></com-aside>
    </el-aside>
    <!-- 右侧内容主体 -->
    <el-container>
      <!-- 头部区域 -->
      <el-header>
        <breadcrumb></breadcrumb>
        <div class="header-right">
          <!-- 图像信息 -->
          <div style="float: left">
            <el-image
              style="width: 50px; height: 50px; border-radius: 10px"
              :src="url"
            ></el-image>
          </div>
          <!-- 名称以及展开的个人中心和退出功能 -->
          <div style="margin: 15px 0px 0px 5px; float: left">
            <el-dropdown @command="handleCommand">
              <span class="el-dropdown-link">
                {{setUserName}}<i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="/mySelf"
                  >{{ dropdownMenu.dropdownMenu1 }}
                </el-dropdown-item>
                <el-dropdown-item divided command="/"
                  >{{ dropdownMenu.dropdownMenu2 }}
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
      </el-header>
      <!-- 主体显示内容 -->
      <el-main>
        <!-- 路由占位符 -->
        <router-view>
          <router-link></router-link>
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
import breadcrumb from "../../components/breadcrumb.vue";
import comAside from "../../components/aside.vue"
import { mapState } from 'vuex'
export default {
  components: {
    breadcrumb,
    comAside,
  },
  data() {
    // 返回一个对象
    return {
      // 是否折叠
      isCollapse: false,
      systemName: "光伏投资应用决策系统",
      dropdownMenu: {
        dropdownMenu1: "个人中心",
        dropdownMenu2: "退出登录",
      },
      menulist: [],
      url:
        require('@/page/1632134553151.png')
    };
  },
  computed: {
    ...mapState(['setUserName'])
  },
  methods: {
    handleCommand(command) {
      if (command === "/") {
        // 删除sessionStorage中的数据
        window.sessionStorage.clear()
        window.localStorage.clear()
        // 退出功能实现原理，基于token的方式，只需要销毁本地的token即可，
        // 这样后续就不会携带token，必须重新登录生成一个新的token之后才可以访问页面
        this.$router.push({
          path: command,
        });
        // 删除vuex中的数据，让当前界面刷新就行
        // window.location.reload()
      } else if (command === "/mySelf") {
        window.localStorage.setItem("activePath", " ");
        this.$router.push({
          path: command,
        });
      }
    },
    // 点击按钮，实现菜单的折叠与展开
    toggleCollapse() {
      this.isCollapse = !this.isCollapse;
    },
  },
};
</script>
<style lang="less" scoped>
@import "./index.less";
</style>