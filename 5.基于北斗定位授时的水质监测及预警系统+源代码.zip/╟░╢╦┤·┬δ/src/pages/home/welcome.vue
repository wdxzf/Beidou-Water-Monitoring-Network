<template>
  <div>
    <el-row class="LiRow">
      <el-col :span="5" :offset="2">
        <el-card @click.native="homePage">首页
          <span  class="Lifristi">
            <i class="el-icon-price-tag"></i>
          </span>
        </el-card>
      </el-col>
      <el-col :span="5"  :offset="2">
        <el-card shadow="hover" @click.native="equipmentManagement" class="Litwice">设备管理
          <span>
            <i class="el-icon-monitor"></i>
          </span>
        </el-card>
      </el-col>
      <el-col :span="5" :offset="2">
        <el-card shadow="hover" @click.native="investmentManagement" class="Lithree">投资管理
          <span>
            <i class="el-icon-tickets"></i>
          </span>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  methods:{
    homePage(){
      console.log('此处就是首页');
    },
    equipmentManagement(){
      this.$router.push({
        path: 'manage',
      })
    },
    investmentManagement(){
      this.$router.push({
        path: 'invest',
      })
    },
  },
}
</script>

<style scoped lang="less">
.LiRow{
  margin-top:20%;
  .Lifristi{
  // font-size:300%;
  float: left;
  }
}
.Litwice{
  // height:1%;
  background-color:#f8c67b;
}
.Lithree{
  // height:1%;
  background-color:#c9cdd3
} 
</style>