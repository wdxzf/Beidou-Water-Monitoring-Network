<template>
  <div>
    <el-row>
      <el-col :span="20">
        <el-card shadow="hover" class="mgb20" style="height: 252px">
          <div class="user-info-list">
            上次登录时间：
            <span>2021-9-10</span>
          </div>
          <div class="user-info-list">
            上次登录地点：
            <span>吉首</span>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <div ref="myechart" style="width: 600px; height: 400px"></div>
  </div>
</template>