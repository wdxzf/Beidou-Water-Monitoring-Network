<template>
  <div class="myself">
    <el-row>
      <el-col>
        <el-card>
          <span>个人基本信息</span>
          <el-divider></el-divider>

        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="20" style="margin-top:2%">
      <el-col :span="6">
        <el-card class="box-card">
          <div slot="header" class="clearfix">
            <span>个人信息</span>
          </div>
          <div>
            <p class="rows">
              <el-image :src="url" :onerror="defaultImg">
                <div slot="placeholder" class="image-slot">
                  加载中<span class="dot">...</span>
                </div>
              </el-image>
            </p>
            <div class="rouw avatar-uploader">
              <!-- 上传图片 -->
              <!-- <el-upload
                class="avatar-uploader"
                :http-request="updateImg"
                action="https://jsonplaceholder.typicode.com/posts/"
                :show-file-list="false"
                :auto-upload="true"
              >
                <img v-if="imageUrl" :src="imageUrl" class="avatar" />
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload> -->
            </div>
            <el-divider></el-divider>
            <!-- 个人信息 -->
            <div class="myself-left" v-for="item in myselfInfo" :key="item.index"
            >
              <p>
                <i :class="item.icon"></i>{{ item.lable
                }}<span :data="personalForm">{{
                  personalForm[item.value]
                }}</span>
              </p>
              <el-divider></el-divider>
            </div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="18">
        <el-card>
          <div slot="header" class="clearfix">
            <span>基本资料</span>
          </div>
          <div>
            <el-tabs v-model="activeName" @tab-click="handleClick">
              <el-tab-pane label="基本资料" name="first">
                <el-form
                  :model="personalForm"
                  :rules="rulesPer"
                  ref="personalForm"
                  label-width="100px"
                  label-position="left"
                >
                  <el-form-item
                    :label="item.label"
                    v-for="item in userLabel"
                    :key="item.index"
                    :prop="item.value"
                  >
                    <el-input
                      :maxlength="item.value === 'userPhone' ? 11 : ''"
                      :placeholder="personalForm[item.placeholder]"
                      v-model="personalForm[item.value]"
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="性别">
                    <el-radio-group v-model="personalForm.userSex">
                      <el-radio :label="1">男</el-radio>
                      <el-radio :label="0">女</el-radio>
                    </el-radio-group>
                  </el-form-item>
                  <el-form-item>
                    <el-button
                      type="primary"
                      @click="submitPerForm('personalForm')"
                      size="medium"
                      >保存</el-button
                    >
                    <el-button @click="goBack()" size="medium" type="danger"
                      >关闭</el-button
                    >
                  </el-form-item>
                </el-form>
              </el-tab-pane>
              <el-tab-pane label="修改密码" name="second">
                <!-- 修改密码 -->
                <el-form
                  :model="ruleForm"
                  status-icon
                  :rules="rules"
                  ref="ruleForm"
                  label-width="100px"
                  class="demo-ruleForm"
                  label-position="left"
                >
                  <el-form-item label="旧密码" prop="oldPassword">
                    <el-input
                      type="password"
                      placeholder="请输入旧密码"
                      v-model="ruleForm.oldPassword"
                      autocomplete="off"
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="新密码" prop="newPassword">
                    <el-input
                      type="password"
                      placeholder="请输入新密码"
                      v-model="ruleForm.newPassword"
                      autocomplete="off"
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="确认密码" prop="checkPassword">
                    <el-input
                      type="password"
                      placeholder="请再次输入新密码"
                      v-model="ruleForm.checkPassword"
                      autocomplete="off"
                    ></el-input>
                  </el-form-item>
                  <el-form-item>
                    <el-button
                      type="primary"
                      @click="submitForm('ruleForm')"
                      size="medium"
                      >保存</el-button
                    >
                    <el-button @click="resetForm('ruleForm')" size="medium"
                      >重置</el-button
                    >
                  </el-form-item>
                </el-form>
              </el-tab-pane>
            </el-tabs>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import api from "api";
export default {
  inject: ["reload"],
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else {
        if (this.ruleForm.checkPassword !== "") {
          this.$refs.ruleForm.validateField("checkPassword");
        }
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请再次输入密码"));
      } else if (value !== this.ruleForm.newPassword) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      Userdata:[],
      url:
        require("@/page/1632134553151.png"),
      defaultImg: 'this.src="' + require("@/assets/logo.png") + '"',
      imageUrl: "",
      //导入文件
      file: {},
      fileList: [],
      myselfInfo: [
        {
          icon: "el-icon-user",
          lable: "用户姓名",
          value: "userName",
        },
        {
          icon: "el-icon-user-solid",
          lable: "用户昵称",
          value: "userNickname",
        },
        {
          icon: "el-icon-phone",
          lable: "手机号码",
          value: "userPhone",
        },
        {
          icon: "el-icon-message",
          lable: "用户邮箱",
          value: "userEmail",
        },
        {
          icon: "el-icon-date",
          lable: "创建时间",
          value: "createDate",
        },
        {
          icon: "el-icon-warning-outline",
          lable: "备注",
          value: "remake",
        },
      ],
      activeName: "first",
      ruleForm: {
        oldPassword: "",
        newPassword: "",
        checkPassword: "",
      },
      rules: {
        oldPassword: [
          { required: true, message: "请输入旧密码", trigger: "blur" },
        ],
        newPassword: [
          { validator: validatePass, trigger: "blur" },
          { required: true, message: "请输入新密码", trigger: "blur" },
        ],
        checkPassword: [
          { validator: validatePass2, trigger: "blur" },
          { required: true, message: "请再次输入新密码", trigger: "blur" },
        ],
      },
      rulesPer: {
        userNickname: [{ required: true, message: "请输入昵称", trigger: "blur" }],
        userPhone: [{ required: true, message: "请输入手机号", trigger: "blur" }],
        userEmail: [
          { required: true, message: "请输入邮箱地址", trigger: "blur" },
          {
            type: "email",
            message: "请输入正确的邮箱地址",
            trigger: ["blur", "change"],
          },
        ],
      },
      userLabel: [
        { label: "用户昵称", value: "userNickname", placeholder: "请输入用户昵称" },
        { label: "手机号码", value: "userPhone", placeholder: "请输入手机号码" },
        { label: "邮箱", value: "userEmail", placeholder: "请输入邮箱" },
      ],
      personalForm: {
        userId:'',
        userName:'',
        userNickname:'',
        userSex:'',
        userPhone:'',
        createDate:'',
        userEmail:'',
      },
    };
  },
  created() {},
  mounted(){
    this.Username()
  },
  methods: {
    all(data, flag, val) {
      if (data.code === 200) {
        this[val] = data.data;
        if (Array.isArray(data.data)) {
          this.totalNum = data.data.length;
        }
        if (flag) this.$message.success(data.message);
        if (flag) this.reload();
      } else {
        if (flag) this.$message.error(data.message);
      }
    },
    //菜单栏，根据不同的菜单名称选择不同的api
    handleClick(tab) {
      console.log(tab.name);
    },


    // 光伏的接口
    async Username(){
      const data = await api.queryUserInfo.queryUserInfo(window.localStorage.getItem('userId'))
      // 基本基础
      this.personalForm = data.data
    },
    // 修改个人信息
    submitPerForm(formName) {
      let changeMessage = {
        userName:this.personalForm.userName,
        userNickname:this.personalForm.userNickname,
        userSex:this.personalForm.userSex,
        userPhone:this.personalForm.userPhone,
        userId:this.personalForm.userId,
      }
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const data = await api.updateUserInfo.updateUserInfo(
            changeMessage
          );
          if (data.code === 200) {
            console.log('111111111');
            this.$store.commit("setUserName", this.personalForm.userNickname);
              this.$message.success(data.message);
            } else {
              this.$message.error(data.message);
            }
        } else {
          return false;
        }
      });
    },
    goBack() {
      this.$router.push({
        path: "/index",
      });
    },
    // 提交信息按钮执行的事件 ---- 修改密码
    submitForm(formName) {
      this.$refs[formName].validate(async (valid) => {
        if (valid) {
          const data = await api.updatePersonalPassword.updatePersonalPassword(
            this.ruleForm
          );
          this.all(data, true);
        } else {
          return false;
        }
      });
    },
    //重置按钮
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    // 上传图片
    async updateImg(item) {
      this.file = item.file;
      const fd = new FormData();
      fd.append("File", this.file);
      // let url = "http://10.6.3.108:8080/file/upLoadUserImg";

      // axios.post(url, fd, Headers).then((_res) => {
      //     if (_res.data.code === 200) {
      //     let img = "data:image/jpeg;base64," + _res.data.iHead;
      //     console.log(img,"=====");
      //     console.log(_res.data,'*_res.data');
      //     console.log(_res.data.iHead,'*_res.data.iHead');
      //     // this.userInfo.iHead = http + "static/" + _res.data.url;
      //     this.$message.success(this.file.name + "\t\t图片上传成功");
      //     // this.queryImg();
      //     this.reload();
      //     } else {
      //     this.$message.error(this.file.name + "\t\t图片上传失败，请重新上传");
      //     }
      // });
    },
    //对上传图片的大小、格式进行限制
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isJPG2 = file.type === "image/jpg";
      const isPNG = file.type === "image/png";
      const isLt5M = file.size / 1024 / 1024 < 5;
      if (!isJPG && !isJPG2 && !isPNG) {
        this.$message.warning("只支持jpg或png格式图片");
      }
      if (!isLt5M) {
        this.$message.warning("请上传5MB以内的图片!");
      }
      return (isJPG || isJPG2 || isPNG) && isLt5M;
    },
  },
};
</script>

<style lang="less" scoped>
@import "../../components/css/myself.less";
</style>