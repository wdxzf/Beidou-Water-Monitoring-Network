//登录界面

<template>
  <div class="login_container">
    <div class="popContainer">
      <div class="login_box">
        <!-- 头像区域 -->
        <!-- <div class="avatar_box">
          <img src="../../assets/logo.png" />
        </div> -->
        <h3>光伏投资应用决策系统</h3>
        <div class="login_form">
          <!-- 登录表单区域 -->
          <el-form
            ref="loginFormRef"
            :model="loginForm"
            :rules="loginFormRules"
            label-width="0px"
            class="login_form"
          >
            <br />
            <!-- 用户名 -->
            <el-form-item prop="userAccount" class="login_input">
              <el-input
                v-model="loginForm.userAccount"
                prefix-icon="el-icon-user"
                placeholder="请输入账号"
                @keyup.enter.native="onSubmit"
              ></el-input>
            </el-form-item>
            <!-- 密码 -->
            <el-form-item prop="userPassword" class="login_input">
              <el-input
                v-model="loginForm.userPassword"
                prefix-icon="el-icon-key"
                type="password"
                placeholder="请输入密码"
                @keyup.enter.native="onSubmit"
              ></el-input>
            </el-form-item>
            <!-- 忘记密码 -->
            <el-form-item class="pwd">
              <el-checkbox>记住密码</el-checkbox>
              <router-link to="/forgetPwd" :underline="false" class="forgetpwd"
                >忘记密码</router-link
              >
            </el-form-item>
            <!-- 按钮区域 -->
            <el-form-item>
              <el-button
                class="login-btn"
                type="primary"
                size="medium"
                :loading="laoding"
                @click="onSubmit"
                >登录</el-button
              >
            </el-form-item>
          </el-form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import api from 'api'
export default {
  name: 'Login',
  data() {
    return {
      laoding:false,
      verificationImg: '',
      // 这是登录表单的数据绑定对象
      loginForm: {
        userAccount: '',
        userPassword: '',
      },
      // 这是表单的验证规则对象
      loginFormRules: {
        // 验证用户名是否合法
        userAccount: [
          {
            required: true,
            message: '请输入登录账号',
            trigger: 'blur',
          },
          {
            min: 3,
            max: 20,
            message: '长度在 3 到 20 个字符',
            trigger: 'blur',
          },
        ],
        // 验证密码是否合法
        userPassword: [
          {
            required: true,
            message: '请输入登录密码',
            trigger: 'blur',
          },
          {
            min: 6,
            max: 18,
            message: '长度在 6 到 18 个字符',
            trigger: 'blur',
          },
        ],
      },
    }
  },
  created() {},
  methods: {
    // 点击登录按钮，预验证
    async onSubmit() {
      this.laoding = true
      try{
      const data = await api.login.login({
       userEmail: this.loginForm.userAccount,
       userPassword: this.loginForm.userPassword
      })
        if(data.code === 200){
          // 加载结束
          this.laoding = false
          // 保存userId
          window.localStorage.setItem('userId',data.data.userId);
          window.localStorage.setItem('userAccount',this.loginForm.userAccount);
          window.localStorage.setItem('userPassword',this.loginForm.userPassword);
          this.$message({
            type: 'success',
            message:data.message,
            duration: 800,
          });
          this.$router.push({
          path: '/welcome',
        })
        }else{
          this.laoding = false
          this.$message.error(data.message)
        }
      }catch(error){
        this.laoding = false
        this.$message.error('登录失败，请重试!')
      }
    },
  },
}
</script>

<style lang="less" scoped>
@import './login.less';
</style>
