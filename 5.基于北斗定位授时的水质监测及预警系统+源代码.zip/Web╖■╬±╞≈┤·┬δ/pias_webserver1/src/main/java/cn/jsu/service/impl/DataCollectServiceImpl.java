package cn.jsu.service.impl;

import cn.jsu.dao.DataCollectDao;
import cn.jsu.pojo.web.dto.*;
import cn.jsu.pojo.web.entity.LocateInfo;
import cn.jsu.service.DataCollectService;
import cn.jsu.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author: Lyrcis
 * @date: 2021/9/20
 * @description: 芜湖.
 */

@Service
public class DataCollectServiceImpl implements DataCollectService {
    @Autowired
    DataCollectDao dataCollectDao;



    @Override
    public MainDataDTO queryNowPower(QueryInfo queryInfo) {
        MainDataDTO mainDataDTO = new MainDataDTO();
        mainDataDTO.setMainData(dataCollectDao.queryNowPower(queryInfo));
        OptionalDouble average = mainDataDTO.getMainData().stream().mapToDouble(MainData::getElectricityPower).average();
        if (average.isPresent() ){
            mainDataDTO.setAveragePower(average.getAsDouble());
            return mainDataDTO;
        }
        mainDataDTO.setAveragePower(0.0);
        return mainDataDTO;
    }

    @Override
    public MainDataDTO queryPower(DataQuery dataQuery) {
        MainDataDTO mainDataDTO = new MainDataDTO();
        System.out.println(dataQuery);
        mainDataDTO.setMainData(dataCollectDao.queryPower(dataQuery));
        OptionalDouble average = mainDataDTO.getMainData().stream().mapToDouble(MainData::getElectricityPower).average();
        if (average.isPresent() ){
            mainDataDTO.setAveragePower(average.getAsDouble());
            return mainDataDTO;
        }
        mainDataDTO.setAveragePower(0.0);
        return mainDataDTO;
    }
    @Override
    public ExtraDataDTO queryExtraData(DataQuery dataQuery) {
        ExtraDataDTO extraDataDTO = new ExtraDataDTO();
        extraDataDTO.setExtraData(dataCollectDao.queryExtraData(dataQuery));
        OptionalDouble average1 = extraDataDTO.getExtraData().stream().mapToDouble(ExtraData::getDataHumidity).average();
        OptionalDouble average2 = extraDataDTO.getExtraData().stream().mapToDouble(ExtraData::getDataHumidity).average();
        if(average1.isPresent() && average2.isPresent()){
            extraDataDTO.setAverageHumidity(average1.getAsDouble());
            extraDataDTO.setAverageTemperature(average2.getAsDouble());
            return extraDataDTO;
        }
        extraDataDTO.setAverageHumidity(0.0);
        extraDataDTO.setAverageTemperature(0.0);
        return extraDataDTO;
    }

    @Override
    public ExtraDataDTO queryNowExtraData(QueryInfo queryInfo) {
        ExtraDataDTO extraDataDTO = new ExtraDataDTO();
        extraDataDTO.setExtraData(dataCollectDao.queryNowExtraData(queryInfo));
        OptionalDouble average1 = extraDataDTO.getExtraData().stream().mapToDouble(ExtraData::getDataHumidity).average();
        OptionalDouble average2 = extraDataDTO.getExtraData().stream().mapToDouble(ExtraData::getDataHumidity).average();
        if(average1.isPresent() && average2.isPresent()){
            extraDataDTO.setAverageHumidity(average1.getAsDouble());
            extraDataDTO.setAverageTemperature(average2.getAsDouble());
            return extraDataDTO;
        }
        extraDataDTO.setAverageHumidity(0.0);
        extraDataDTO.setAverageTemperature(0.0);
        return extraDataDTO;
    }

    @Override
    public LocateInfo queryLocate(Integer deviceId) {
        return dataCollectDao.queryLocate(deviceId);
    }

    @Override
    public Map<String, Object> getPowerDataCount(Integer deviceId) {

        // 获取今天结束时间
        String endTime = DateUtils.getNowTime();

        // 获取365天前的日期
        Date temp = DateUtils.getDate(endTime, -365);

        String startTime = DateUtils.dateToStr(temp);

        List<Map<String, Object>> blogContributeMap = dataCollectDao.getPowerDataCount(startTime, endTime,deviceId);
        //拿到有数据的
        List<String> dateList = DateUtils.getDayBetweenDates(startTime, endTime);
        //初始化去年一年的数据为list
        Map<String, Object> dateMap = new HashMap<>();

        for(Map<String, Object> itemMap : blogContributeMap) {
            //将对应的赋值
            dateMap.put(itemMap.get("DATE").toString(), itemMap.get("COUNT"));
        }

        List<List<Object>> resultList = new ArrayList<>();
        for(String item : dateList) {
            int count = 0;
            if(dateMap.get(item) != null) {
                count = Integer.parseInt(dateMap.get(item).toString());
            }
            List<Object> objectList = new ArrayList<>();
            objectList.add(item);
            objectList.add(count);
            resultList.add(objectList);
        }
        //在LIST里面加一个list里面的list是一对，日期和其值
        Map<String, Object> resultMap = new HashMap<>();
        List<String> contributeDateList = new ArrayList<>();
        contributeDateList.add(startTime);
        contributeDateList.add(endTime);
        //传入输入输出时间
        resultMap.put("contributeDate", contributeDateList);
        resultMap.put("PowerDataCount", resultList);

        return resultMap;
    }
}
