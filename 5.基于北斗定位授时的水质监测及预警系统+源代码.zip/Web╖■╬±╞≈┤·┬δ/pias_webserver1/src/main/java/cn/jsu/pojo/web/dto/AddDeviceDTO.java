package cn.jsu.pojo.web.dto;

import cn.jsu.pojo.web.entity.DeviceInfo;

public class AddDeviceDTO {
    private DeviceInfo deviceInfo;
    private Integer userId;

    public AddDeviceDTO() {
    }

    public AddDeviceDTO(DeviceInfo deviceInfo, Integer userId) {
        this.deviceInfo = deviceInfo;
        this.userId = userId;
    }

    public DeviceInfo getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(DeviceInfo deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    @Override
    public String toString() {
        return "AddDeviceDTO{" +
                "deviceInfo=" + deviceInfo +
                ", userId=" + userId +
                '}';
    }
}
