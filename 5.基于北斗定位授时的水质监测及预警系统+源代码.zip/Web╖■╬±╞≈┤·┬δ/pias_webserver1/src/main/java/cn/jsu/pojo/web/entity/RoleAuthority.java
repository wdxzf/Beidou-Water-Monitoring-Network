package cn.jsu.pojo.web.entity;

import java.io.Serializable;

public class RoleAuthority implements Serializable {
    Integer raId;
    Integer accountId;
    Integer roleId;

    public RoleAuthority(Integer raId, Integer accountId, Integer roleId) {
        this.raId = raId;
        this.accountId = accountId;
        this.roleId = roleId;
    }

    public Integer getRaId() {
        return raId;
    }

    public void setRaId(Integer raId) {
        this.raId = raId;
    }

    public Integer getAccountId() {
        return accountId;
    }

    public void setAccountId(Integer accountId) {
        this.accountId = accountId;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    @Override
    public String toString() {
        return "RoleAuthority{" +
                "raId=" + raId +
                ", accountId=" + accountId +
                ", roleId=" + roleId +
                '}';
    }
}
