package cn.jsu.controller;

import cn.jsu.pojo.net.DeviceInformation;
import cn.jsu.pojo.web.dto.AddDeviceDTO;
import cn.jsu.pojo.web.dto.DeviceInfoVO;
import cn.jsu.pojo.web.dto.QueryDeviceDetailsDTO;
import cn.jsu.pojo.web.dto.QueryDeviceListDTO;
import cn.jsu.pojo.web.entity.City;
import cn.jsu.pojo.web.entity.DeviceInfo;
import cn.jsu.pojo.web.vo.CommonResult;
import cn.jsu.service.DeviceService;
//import cn.jsu.utils.SecurityUtils;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author: Lyrcis
 * @date: 2021/10/17
 * @description: 芜湖.
 */
@CrossOrigin
@RestController
@RequestMapping("/device")
public class DeviceController {
    @Autowired
    DeviceService deviceService;


    /**
     * @author lr
     * @param addDeviceDTO Topic package
     * @return CommonResult
     */
    @PostMapping("/addDevice")
    @ApiOperation("添加设备")
     public CommonResult<Object> addDevice(@RequestBody AddDeviceDTO addDeviceDTO){
        return deviceService.addDevice(addDeviceDTO);
    }

    @PostMapping("/queryAddress")
    @ApiOperation("查询地区")
    public CommonResult queryAddress(@RequestBody Integer pid) {
        List<City> cities = deviceService.queryAddress(pid);
        return new CommonResult<>(200,"查询地区成功",cities);
    }

    @PostMapping("/updateDevice")
    @ApiOperation("修改设备信息")
    public CommonResult updateDevice(@RequestBody DeviceInfo deviceInfo) {
//        device.setUpdateBy(SecurityUtils.getUsername());//修改设备不需要说是谁。
        deviceService.updateDeviceInfo(deviceInfo);
        return new CommonResult<>(200,"更新设备成功");
    }


    @PostMapping("/deleteDevice")
    @ApiOperation("删除设备信息列表")
    public CommonResult deleteDevice(@RequestBody List<Integer> deviceIds) {
        deviceService.deleteDevice(deviceIds);
        return new CommonResult<>(200,"删除设备成功");
    }

//    @PostMapping("/details")
//    @ApiOperation("查看设备详细信息")
//    public CommonResult deviceDetails(@RequestBody Integer deviceId) {
//        Device device = deviceServer.selectDeviceDetails(deviceId);
//        return CommonResult.select(device);
//    }

        @PostMapping("/queryDeviceDetails")
    @ApiOperation("查看设备详细信息")
    public CommonResult queryDeviceDetails(@RequestBody QueryDeviceDetailsDTO queryDeviceDetailsDTO) {
        DeviceInfo deviceInfo = deviceService.queryDeviceDetails(queryDeviceDetailsDTO);
            return new CommonResult<>(200,"查询成功",deviceInfo);
    }

    @PostMapping("/queryDeviceList")
    @ApiOperation("查看设备信息列表")
    public CommonResult queryDeviceDetails(@RequestBody QueryDeviceListDTO queryDeviceListDTO) {
        List<DeviceInfoVO> list = deviceService.queryDeviceList(queryDeviceListDTO);
        return new CommonResult<>(200,"查询成功",list);
    }

    @PostMapping("/switchLight")
    @ApiOperation("设备开关灯")
    public CommonResult<?> testDataTransmission(@RequestBody DeviceInformation deviceInformation) {
        return deviceService.TestDataTransmission(deviceInformation);
    }


//
//    @PostMapping("/checkDeviceEuiUnique")
//    @ApiOperation("检查设备eui是否正确")
//    public CommonResult checkDeviceEuiUnique(@RequestBody(required = false) String deviceEui) {
//        if (deviceEui == null) {
//            return CommonResult.error("请输入设备EUI");
//        }
//        if (!ToolUtil.checkIsHexadecimal(deviceEui) || deviceEui.length() != 16) {
//            return CommonResult.error("该设备EUI格式错误");
//        }
//        if (!deviceServer.checkDeviceEuiUnique(deviceEui)) {
//            return CommonResult.fail("该设备EUI已被注册");
//        }
//        return CommonResult.success("该设备Eui可以注册");
//    }
//
//    @PostMapping("/selectDeviceByAddressId")
//    @ApiOperation("根据地址查询设备 ")
//    public CommonResult selectDeviceByAddressId(@RequestBody Integer addressId) {
//        Integer userId = SecurityUtils.getUserId();
//        List<Device> list = deviceServer.selectDeviceListByAddressId(userId, addressId);
//        return CommonResult.select(list);
//    }
//
//
//    @PostMapping("/workParameters")
//    @ApiOperation("查看设备工作参数接口")
//    public CommonResult selectDeviceWorkParameters(@RequestBody Integer deviceId) {
//        DeviceWorkParameters deviceWorkParameters = deviceServer.selectDeviceWorkParameters(deviceId);
//        return CommonResult.select(deviceWorkParameters);
//    }
//
//    @PostMapping("/authorize")
//    @ApiOperation("授权")
//    private CommonResult authorizeDevice(@RequestBody AuthorizeDTO dto) {
//        UserInfo userInfo = userServer.selectUserInfoByUsername(dto.getUsername());
//        if (userInfo == null) {
//            return CommonResult.error("用户不存在");
//        }
//        deviceServer.authorizeDevice(dto.getIds(), userInfo.getUserId());
//        return CommonResult.success("授权成功");
//    }
}
