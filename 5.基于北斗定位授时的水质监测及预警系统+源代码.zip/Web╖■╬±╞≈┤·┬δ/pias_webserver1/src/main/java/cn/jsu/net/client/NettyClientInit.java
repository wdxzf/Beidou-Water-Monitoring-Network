package cn.jsu.net.client;


import cn.jsu.net.handler.InBoundHandler;
import cn.jsu.net.handler.OutBoundHandler;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.socket.SocketChannel;

/**
 * @author: suixuexue
 * @date: 2020/11/4 20:41
 * describe:
 */
public class NettyClientInit extends ChannelInitializer<SocketChannel> {

    @Override
    protected void initChannel(SocketChannel socketChannel) throws Exception {
        socketChannel.pipeline()
                .addLast(new OutBoundHandler())
                .addLast(new InBoundHandler())
                .addLast(new NettyClientInHandler());
    }

}
