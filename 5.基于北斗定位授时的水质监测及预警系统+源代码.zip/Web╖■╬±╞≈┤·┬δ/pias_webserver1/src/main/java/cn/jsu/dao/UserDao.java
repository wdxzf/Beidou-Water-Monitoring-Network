package cn.jsu.dao;

//import cn.jsu.pojo.web.dto.UserInformation;
import cn.jsu.pojo.web.vo.LoginResponseVo;
import cn.jsu.pojo.web.vo.LoginVo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface UserDao {
//    int queryEmail(String userEmail);
//
//    int insertUserInfo(UserInformation userInfo);

    LoginResponseVo login(LoginVo loginVo);

    /**
     * 查询userid
     * @param loginVo 登录账号密码
     * @return userid
     */
    Integer queryUserId(LoginVo loginVo);
}
