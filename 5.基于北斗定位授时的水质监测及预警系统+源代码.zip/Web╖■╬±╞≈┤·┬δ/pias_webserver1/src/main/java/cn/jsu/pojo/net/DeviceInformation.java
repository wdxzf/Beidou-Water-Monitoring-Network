package cn.jsu.pojo.net;

import cn.jsu.parsing.Pack;
import cn.jsu.parsing.PackType;

/**
 * @author Tieria
 * @date 2021/12/8
 * @description:
 */
@PackType(typeNo = 10)
public class DeviceInformation extends Pack {

    private Integer deviceId;

    private Integer lightId;

    private String deviceIp;


    /**
     * 现在暂时 "O"  "F"
     * */
    private String command;

    public DeviceInformation(Integer deviceId, Integer lightId, String deviceIp, String command) {
        this.deviceId = deviceId;
        this.lightId = lightId;
        this.deviceIp = deviceIp;
        this.command = command;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getLightId() {
        return lightId;
    }

    public void setLightId(Integer lightId) {
        this.lightId = lightId;
    }

    public String getDeviceIp() {
        return deviceIp;
    }

    public void setDeviceIp(String deviceIp) {
        this.deviceIp = deviceIp;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    @Override
    public String toString() {
        return "DeviceInformation{" +
                "deviceId=" + deviceId +
                ", lightId=" + lightId +
                ", deviceIp='" + deviceIp + '\'' +
                ", command='" + command + '\'' +
                '}';
    }
}
