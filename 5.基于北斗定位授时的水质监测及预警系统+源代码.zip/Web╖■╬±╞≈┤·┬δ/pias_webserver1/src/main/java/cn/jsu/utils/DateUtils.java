package cn.jsu.utils;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Chiaki
 */
public class DateUtils {
    /**
     * 获取某个时间段内所有日期
     * @param begin 开始时间
     * @param end 结束时间
     * @return list date
     */
    public static List<String> getDayBetweenDates(String begin, String end) {
        Date dBegin = strToDate(begin);
        Date dEnd = strToDate(end);
        List<String> lDate = new ArrayList<String>();
        SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
        lDate.add(sd.format(dBegin));
        Calendar calBegin = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calBegin.setTime(dBegin);
        Calendar calEnd = Calendar.getInstance();
        // 使用给定的 Date 设置此 Calendar 的时间
        calEnd.setTime(dEnd);
        // 测试此日期是否在指定日期之后
        while (dEnd.after(calBegin.getTime())) {
            // 根据日历的规则，为给定的日历字段添加或减去指定的时间量
            calBegin.add(Calendar.DAY_OF_MONTH, 1);
            lDate.add(sd.format(calBegin.getTime()));
        }
        return lDate;
    }


    public static String getNowTime() {
        return dateToStr(new Date());
    }

    /**
     * 日期转换成字符串
     * @param date 日期
     * @return str
     */
    public static String dateToStr(Date date) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String str = format.format(date);
        return str;
    }

    /**
     * 字符串转换成日期
     * @param str 字符串
     * @return date
     */
    public static Date strToDate(String str) {

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    /**
     *
     * @param endTime 现在时间
     * @param i 多少天之后
     * @return date 返回时间
     */
    public static Date getDate(String endTime, int i) {
        return new Date(strToDate(endTime).getTime() + (long)i * 24 * 60 * 60 * 1000);
    }
}
