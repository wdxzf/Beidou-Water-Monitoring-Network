package cn.jsu.pojo.web.entity;

import java.io.Serializable;
import java.sql.Date;


public class DeviceInfo implements Serializable {
    Integer deviceId;
    String deviceEui;
    String deviceName;
    String deviceAddres;
    String deviceType;
    Integer deviceAngle;
    String deviceSpecification;
    Integer deviceVoltag;
    Integer devicePower;
    Integer deviceRange;
    String deviceMark;
    Integer delFlag;
    Date createDate;
    Integer addressId;

    public DeviceInfo() {
    }

    public DeviceInfo(Integer deviceId, String deviceEui, String deviceName, String deviceAddres, String deviceType, Integer deviceAngle, String deviceSpecification, Integer deviceVoltag, Integer devicePower, Integer deviceRange, String deviceMark, Integer delFlag, Date createDate, Integer addressId) {
        this.deviceId = deviceId;
        this.deviceEui = deviceEui;
        this.deviceName = deviceName;
        this.deviceAddres = deviceAddres;
        this.deviceType = deviceType;
        this.deviceAngle = deviceAngle;
        this.deviceSpecification = deviceSpecification;
        this.deviceVoltag = deviceVoltag;
        this.devicePower = devicePower;
        this.deviceRange = deviceRange;
        this.deviceMark = deviceMark;
        this.delFlag = delFlag;
        this.createDate = createDate;
        this.addressId = addressId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceEui() {
        return deviceEui;
    }

    public void setDeviceEui(String deviceEui) {
        this.deviceEui = deviceEui;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceAddres() {
        return deviceAddres;
    }

    public void setDeviceAddres(String deviceAddres) {
        this.deviceAddres = deviceAddres;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public Integer getDeviceAngle() {
        return deviceAngle;
    }

    public void setDeviceAngle(Integer deviceAngle) {
        this.deviceAngle = deviceAngle;
    }

    public String getDeviceSpecification() {
        return deviceSpecification;
    }

    public void setDeviceSpecification(String deviceSpecification) {
        this.deviceSpecification = deviceSpecification;
    }

    public Integer getDeviceVoltag() {
        return deviceVoltag;
    }

    public void setDeviceVoltag(Integer deviceVoltag) {
        this.deviceVoltag = deviceVoltag;
    }

    public Integer getDevicePower() {
        return devicePower;
    }

    public void setDevicePower(Integer devicePower) {
        this.devicePower = devicePower;
    }

    public Integer getDeviceRange() {
        return deviceRange;
    }

    public void setDeviceRange(Integer deviceRange) {
        this.deviceRange = deviceRange;
    }

    public String getDeviceMark() {
        return deviceMark;
    }

    public void setDeviceMark(String deviceMark) {
        this.deviceMark = deviceMark;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Integer getAddressId() {
        return addressId;
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    @Override
    public String toString() {
        return "DeviceInfo{" +
                "deviceId=" + deviceId +
                ", deviceEui='" + deviceEui + '\'' +
                ", deviceName='" + deviceName + '\'' +
                ", deviceAddres='" + deviceAddres + '\'' +
                ", deviceType='" + deviceType + '\'' +
                ", deviceAngle=" + deviceAngle +
                ", deviceSpecification='" + deviceSpecification + '\'' +
                ", deviceVoltag=" + deviceVoltag +
                ", devicePower=" + devicePower +
                ", deviceRange=" + deviceRange +
                ", deviceMark='" + deviceMark + '\'' +
                ", delFlag=" + delFlag +
                ", createDate=" + createDate +
                ", addressId=" + addressId +
                '}';
    }
}