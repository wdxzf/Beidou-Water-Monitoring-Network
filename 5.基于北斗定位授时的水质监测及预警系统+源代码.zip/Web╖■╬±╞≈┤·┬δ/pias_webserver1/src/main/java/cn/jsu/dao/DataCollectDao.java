package cn.jsu.dao;

import cn.jsu.pojo.web.dto.DataQuery;
import cn.jsu.pojo.web.dto.ExtraData;
import cn.jsu.pojo.web.dto.MainData;
import cn.jsu.pojo.web.dto.QueryInfo;
import cn.jsu.pojo.web.entity.LocateInfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author: Lyrics
 * @date: 2021/9/20
 * @describe: ddd.
 */

@Mapper
@Repository
public interface DataCollectDao {
    ArrayList<MainData> queryPower(DataQuery dataQuery);

    ArrayList<MainData> queryNowPower(QueryInfo queryInfo);

    List<ExtraData> queryExtraData(DataQuery dataQuery);

    List<ExtraData> queryNowExtraData(QueryInfo queryInfo);

    LocateInfo queryLocate(Integer deviceId);

    List<Map<String, Object>> getPowerDataCount(@Param("startTime") String startTime,@Param("endTime") String endTime,@Param("deviceId")Integer deviceId);
}
