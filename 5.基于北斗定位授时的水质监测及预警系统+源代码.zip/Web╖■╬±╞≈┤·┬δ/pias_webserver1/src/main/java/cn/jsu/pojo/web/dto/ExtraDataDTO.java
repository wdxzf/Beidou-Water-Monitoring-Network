package cn.jsu.pojo.web.dto;

import java.util.List;

public class ExtraDataDTO {
    private Double averageTemperature;
    private Double averageHumidity;
    private List<ExtraData> extraData;

    @Override
    public String toString() {
        return "ExtraDataDTO{" +
                "averageTemperature=" + averageTemperature +
                ", averageHumidity=" + averageHumidity +
                ", extraData=" + extraData +
                '}';
    }

    public Double getAverageTemperature() {
        return averageTemperature;
    }

    public void setAverageTemperature(Double averageTemperature) {
        this.averageTemperature = averageTemperature;
    }

    public Double getAverageHumidity() {
        return averageHumidity;
    }

    public void setAverageHumidity(Double averageHumidity) {
        this.averageHumidity = averageHumidity;
    }

    public List<ExtraData> getExtraData() {
        return extraData;
    }

    public void setExtraData(List<ExtraData> extraData) {
        this.extraData = extraData;
    }

    public ExtraDataDTO() {
    }

    public ExtraDataDTO(Double averageTemperature, Double averageHumidity, List<ExtraData> extraData) {
        this.averageTemperature = averageTemperature;
        this.averageHumidity = averageHumidity;
        this.extraData = extraData;
    }
}
