package cn.jsu.pojo.net;

import cn.jsu.parsing.Pack;

/**
 * @author Tieria
 * @date 2021/12/8
 * @description:
 */
public class DataTransmission extends Pack {

}
