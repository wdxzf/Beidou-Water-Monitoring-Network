package cn.jsu.service;

import cn.jsu.pojo.web.vo.LoginVo;
//import cn.jsu.pojo.web.dto.UserInformation;
import cn.jsu.pojo.web.vo.CommonResult;

import javax.servlet.http.HttpServletRequest;

public interface UserService {
//    int regist(UserInformation userInfo);

    CommonResult<Object> login(LoginVo loginVo , HttpServletRequest request);

    Integer queryUserId(LoginVo loginVo);
}
