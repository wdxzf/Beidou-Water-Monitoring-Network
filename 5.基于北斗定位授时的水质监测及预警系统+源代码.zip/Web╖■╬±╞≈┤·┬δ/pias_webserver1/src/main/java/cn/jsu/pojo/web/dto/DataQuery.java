package cn.jsu.pojo.web.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.sql.Date;
import java.sql.Timestamp;


public class DataQuery {
    Integer deviceId;
    Timestamp measureTime1;
    Timestamp measureTime2;

    public DataQuery() {
    }

    public DataQuery(Integer deviceId, Timestamp measureTime1, Timestamp measureTime2) {
        this.deviceId = deviceId;
        this.measureTime1 = measureTime1;
        this.measureTime2 = measureTime2;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Timestamp getMeasureTime1() {
        return measureTime1;
    }

    public void setMeasureTime1(Timestamp measureTime1) {
        this.measureTime1 = measureTime1;
    }

    public Timestamp getMeasureTime2() {
        return measureTime2;
    }

    public void setMeasureTime2(Timestamp measureTime2) {
        this.measureTime2 = measureTime2;
    }

    @Override
    public String toString() {
        return "DataQuery{" +
                "deviceId=" + deviceId +
                ", measureTime1=" + measureTime1 +
                ", measureTime2=" + measureTime2 +
                '}';
    }
}
