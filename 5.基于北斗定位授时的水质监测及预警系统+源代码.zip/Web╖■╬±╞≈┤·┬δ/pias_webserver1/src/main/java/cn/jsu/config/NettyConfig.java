package cn.jsu.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @Auther: suixuexue
 * @Date: 2020/12/25/21:30
 * @Description: Netty配置，读取YAML配置
 */
@Slf4j
@Component
@ConfigurationProperties(prefix = "netty")
public class NettyConfig
{
    private String ip;
    private int port;
    private int sizeIn;
    private int sizeOut;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String passeword) {
        this.password = passeword;
    }



    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public int getPort()
    {
        return port;
    }

    public void setPort(int port)
    {
        this.port = port;
    }

    public int getSizeIn()
    {
        return sizeIn;
    }

    public void setSizeIn(int sizeIn)
    {
        this.sizeIn = sizeIn;
    }

    public int getSizeOut()
    {
        return sizeOut;
    }

    public void setSizeOut(int sizeOut)
    {
        this.sizeOut = sizeOut;
    }

}