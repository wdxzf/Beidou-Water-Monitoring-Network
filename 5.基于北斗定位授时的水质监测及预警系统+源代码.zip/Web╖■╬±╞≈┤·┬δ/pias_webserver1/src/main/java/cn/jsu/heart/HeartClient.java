package cn.jsu.heart;


import cn.jsu.config.ResourceConfig;
import cn.jsu.net.client.NettyClientInHandler;
import lombok.extern.slf4j.Slf4j;


@Slf4j
public class HeartClient {
    public static boolean isHeart = false;   //静态变量
    private int sleepTime;
    private boolean isClose = false;

    public HeartClient() {
        sleepTime = ResourceConfig.getConfigInteger("web.heart.sleep.time",5000);
    }

    /**
     * Q:
     *  1. 客户端应该主动发送心跳？  但是这里的我怎么感觉是被动的
     *  2. 心跳断一次就通道就关闭了？ 没有重连机制？
     * A：
     *  1. 客户端在连接上服务器的时候就手动发送心跳了 所以这里的处理是先接在发
     *  2. 是的心跳断一次通道就关闭了 没有重连机制
     *
     *  关于isHeart变量
     *  初始是flase 客户端第一次连上服务器时会发送心跳包 服务器回包
     *  客户端这边接包 当发现对面pang过来的时候 就继续ping
     *              if (isHeart)
     *             {
     *                 sendHeart();
     *                 isHeart = false;
     *             }
     *  这样处理是因为前人设计说需要一直ping pang 不能中断
     *  断了
     * */
    public void run()
    {
        while (!isClose)
        {
            try {
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            log.info(String.valueOf(isHeart));
            if (isHeart)
            {
                sendHeart();
                isHeart = false;
            } else {
                outTimeHandle();
            }
        }
    }

    private void sendHeart()
    {
        HeartInformation heartInformation = new HeartInformation();
        try {
            NettyClientInHandler.getChannel().writeAndFlush(heartInformation.serialize());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void outTimeHandle()
    {
        log.info("任务调度心跳断开");
        isClose = true;
    }

}
