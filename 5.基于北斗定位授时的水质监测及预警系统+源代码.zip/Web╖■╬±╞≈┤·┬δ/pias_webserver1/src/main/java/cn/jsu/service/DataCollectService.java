package cn.jsu.service;

import cn.jsu.pojo.web.dto.*;
import cn.jsu.pojo.web.entity.LocateInfo;
import cn.jsu.utils.DateUtils;
import io.swagger.models.auth.In;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author: Lyrcis
 * @date: 2021/9/20
 * @description: 芜湖.
 */
@Service
public interface DataCollectService {
    MainDataDTO queryPower(DataQuery dataQuery);

    MainDataDTO queryNowPower(QueryInfo queryInfo);

    ExtraDataDTO queryExtraData(DataQuery dataQuery);

    ExtraDataDTO queryNowExtraData(QueryInfo queryInfo);

    LocateInfo queryLocate(Integer deviceId);

    Map<String, Object> getPowerDataCount(Integer deviceId);
}
