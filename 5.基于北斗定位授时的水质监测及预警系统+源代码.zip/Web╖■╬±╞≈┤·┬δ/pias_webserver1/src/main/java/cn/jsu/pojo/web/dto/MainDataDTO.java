package cn.jsu.pojo.web.dto;

import java.util.ArrayList;

public class MainDataDTO {
    private Double averagePower;
    private ArrayList<MainData> mainData;

    public MainDataDTO() {
    }

    public MainDataDTO(Double averagePower, ArrayList<MainData> mainData) {
        this.averagePower = averagePower;
        this.mainData = mainData;
    }

    @Override
    public String toString() {
        return "MainDataDTO{" +
                "averagePower=" + averagePower +
                ", mainData=" + mainData +
                '}';
    }

    public Double getAveragePower() {
        return averagePower;
    }

    public void setAveragePower(Double averagePower) {
        this.averagePower = averagePower;
    }

    public ArrayList<MainData> getMainData() {
        return mainData;
    }

    public void setMainData(ArrayList<MainData> mainData) {
        this.mainData = mainData;
    }
}
