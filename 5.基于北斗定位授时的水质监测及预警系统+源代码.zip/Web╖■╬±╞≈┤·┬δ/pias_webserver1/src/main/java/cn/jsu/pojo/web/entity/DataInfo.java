package cn.jsu.pojo.web.entity;

import java.awt.dnd.DropTarget;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Timestamp;

public class DataInfo implements Serializable {
    Integer dataId;
    Integer deviceId;
    Date measureTime;
    BigDecimal electricityPower;

    @Override
    public String toString() {
        return "DataInfo{" +
                "dataId=" + dataId +
                ", deviceId=" + deviceId +
                ", measureTime=" + measureTime +
                ", electricityPower=" + electricityPower +
                '}';
    }

    public Integer getDataId() {
        return dataId;
    }

    public void setDataId(Integer dataId) {
        this.dataId = dataId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Date getMeasureTime() {
        return measureTime;
    }

    public void setMeasureTime(Date measureTime) {
        this.measureTime = measureTime;
    }

    public BigDecimal getElectricityPower() {
        return electricityPower;
    }

    public void setElectricityPower(BigDecimal electricityPower) {
        this.electricityPower = electricityPower;
    }

    public DataInfo(Integer dataId, Integer deviceId, Date measureTime, BigDecimal electricityPower) {
        this.dataId = dataId;
        this.deviceId = deviceId;
        this.measureTime = measureTime;
        this.electricityPower = electricityPower;
    }
}
