package cn.jsu.parsing;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 标识包类型
 * @author suixuexue
 */
@Retention(value = RetentionPolicy.RUNTIME)
@Target(value = ElementType.TYPE)
public @interface PackType {
    /**
     * 包编号用于唯一确定一个实体类
     * @return  包编号
     */
    public short typeNo();

    /**
     * 指定是否使用父类型属性,优先使用父类型属性序列化
     */
    public Class<?>[] superClass() default {};
}
