package cn.jsu.service.impl;

import cn.jsu.dao.DeviceDao;
import cn.jsu.pojo.net.DataTransmission;
import cn.jsu.pojo.net.DeviceInformation;
import cn.jsu.pojo.web.dto.AddDeviceDTO;
import cn.jsu.pojo.web.dto.DeviceInfoVO;
import cn.jsu.pojo.web.dto.QueryDeviceDetailsDTO;
import cn.jsu.pojo.web.dto.QueryDeviceListDTO;
import cn.jsu.pojo.web.entity.City;
import cn.jsu.pojo.web.entity.DeviceInfo;
import cn.jsu.pojo.web.vo.CommonResult;
import cn.jsu.service.DeviceService;
import cn.jsu.utils.ToolUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;


/**
 * @author: Lyrcis
 * @date: 2021/10/17
 * @description: 芜湖.
 */


@Service
public class DeviceServiceImpl implements DeviceService {

    @Autowired
    DeviceDao deviceDao;

    /**
     * 这里需要修改 使用自己需要发送的数据包类
     * */
    private LinkedBlockingQueue<DeviceInformation> linkedBlockingQueue;

    public void setLinkedBlockingQueue(LinkedBlockingQueue linkedBlockingQueue)
    {
        this.linkedBlockingQueue = linkedBlockingQueue;
    }


    /**
     * 检查设备eui是否重复
     * @param deviceEui 设备eui
     * @return 结果
     */
    private Boolean checkDeviceEuiUnique(String deviceEui) {
        Integer count = deviceDao.checkDeviceEuiUnique(deviceEui);
        return count <= 0;
    }

    /**
     * 添加设备
     * @param addDeviceDTO 设备基本信息
     * @return 结果
     */
    @Override
    public CommonResult<Object> addDevice(AddDeviceDTO addDeviceDTO) {
        DeviceInfo deviceInfo = addDeviceDTO.getDeviceInfo();
        Integer userId = addDeviceDTO.getUserId();
        if (!checkDeviceEuiUnique(deviceInfo.getDeviceEui())) {
            return new CommonResult<>(444,"设备EUI:'" + deviceInfo.getDeviceEui() + "'已被注册");
        }

        if (!ToolUtil.checkIsHexadecimal(deviceInfo.getDeviceEui()) || deviceInfo.getDeviceEui().length() != 8) {
            return new CommonResult<>(444,"该设备EUI格式错误");
        }

        deviceDao.addDevice(deviceInfo);
        deviceDao.addUserDevice(userId,deviceInfo.getDeviceId());
        return new CommonResult<>(200,"添加成功");

    }


    /**
     * 更新设备基本信息
     * @param deviceInfo 所更新的设备信息
     * @return 结果
     */
    @Override
    public void updateDeviceInfo(DeviceInfo deviceInfo){
        deviceDao.updateDeviceInfo(deviceInfo);
    }
    /**
     * 删除设备
     * @param deviceIds 设备id
     * @return 结果
     */
    @Override
    public void deleteDevice(List<Integer> deviceIds){
            deviceDao.deleteDevice(deviceIds);
    }


    /**
     * 查询用户设备列表
     * @param queryDeviceListDTO 用户id
     * @return 结果
     */
    @Override
    public List<DeviceInfoVO> queryDeviceList(QueryDeviceListDTO queryDeviceListDTO) {
        List<DeviceInfoVO> deviceInfos = deviceDao.queryDeviceList(queryDeviceListDTO);
        for (DeviceInfoVO deviceInfo : deviceInfos) {
            deviceInfo.setAddress(getDeviceDetailedAddress(deviceInfo.getAddressId(),
                                                           deviceInfo.getDeviceAddres()));
            deviceInfo.setDeviceAddres(null);
        }
        return deviceInfos;
    }


    public List<String> getDeviceDetailedAddress(Integer id,String deviceAddress){
        List<String> addressList = new ArrayList<>();
        if(deviceAddress!=null&&deviceAddress!=""){
            addressList.add(deviceAddress);
        }
        City city;
        city = deviceDao.queryAddressById(id);
        while (city!=null){
            addressList.add(city.getCityname());
            if(city.getPid()==1){
                break;
            }
            city = deviceDao.queryAddressById(city.getPid());
        }
        Collections.reverse(addressList);
        return addressList;
    }
    /**
     * 查询设备基本信息
     * @param queryDeviceDetailsDTO 查询信息
     * @return 结果
     */
    @Override
    public DeviceInfo queryDeviceDetails(QueryDeviceDetailsDTO queryDeviceDetailsDTO) {
        return deviceDao.queryDeviceDetails(queryDeviceDetailsDTO.getDeviceId(),queryDeviceDetailsDTO.getUsrId());
    }


    /**
     * 查询位置
     * @param pid 父类地区id
     * @return 结果
     */
    @Override
    public List<City> queryAddress(Integer pid) {
        return deviceDao.queryAddress(pid);
    }

    /**
     * 测试数据传输
    * */
    @Override
    public CommonResult<?> TestDataTransmission(DeviceInformation deviceInformation) {
        try {
            System.out.println(deviceInformation);
            deviceInformation.setDeviceIp(deviceDao.queryDeviceIpById(deviceInformation.getDeviceId()));
            linkedBlockingQueue.put(deviceInformation);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return CommonResult.ok(200);
    }
}
