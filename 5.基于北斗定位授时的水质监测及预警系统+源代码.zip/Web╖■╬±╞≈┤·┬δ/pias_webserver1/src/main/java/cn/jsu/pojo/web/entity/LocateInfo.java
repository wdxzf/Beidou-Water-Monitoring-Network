package cn.jsu.pojo.web.entity;

import java.util.Date;

public class LocateInfo {
    private Integer locateId;
    private Integer deviceId;
    private Date measureTime;
    private Double longitude;
    private Double latitude;

    public LocateInfo() {
    }

    public LocateInfo(Integer locateId, Integer deviceId, Date measureTime, Double longitude, Double latitude) {
        this.locateId = locateId;
        this.deviceId = deviceId;
        this.measureTime = measureTime;
        this.longitude = longitude;
        this.latitude = latitude;
    }

    public Integer getLocateId() {
        return locateId;
    }

    public void setLocateId(Integer locateId) {
        this.locateId = locateId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Date getMeasureTime() {
        return measureTime;
    }

    public void setMeasureTime(Date measureTime) {
        this.measureTime = measureTime;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }

    public Double getLatitude() {
        return latitude;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    @Override
    public String toString() {
        return "locateInfo{" +
                "locateId=" + locateId +
                ", deviceId=" + deviceId +
                ", measureTime=" + measureTime +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                '}';
    }
}
