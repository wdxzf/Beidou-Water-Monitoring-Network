package cn.jsu.pojo.web.dto;

public class QueryDeviceListDTO {
    Integer userId;
    String deviceName;
    Integer addressId;

    public QueryDeviceListDTO() {
    }

    public QueryDeviceListDTO(Integer userId, String deviceName, Integer addressId) {
        this.userId = userId;
        this.deviceName = deviceName;
        this.addressId = addressId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Integer getAddressId() {
        return addressId;
    }

    public void setAddressId(Integer addressId) {
        this.addressId = addressId;
    }

    @Override
    public String toString() {
        return "queryDeviceListDTO{" +
                "userId=" + userId +
                ", deviceName='" + deviceName + '\'' +
                ", addressId=" + addressId +
                '}';
    }
}
