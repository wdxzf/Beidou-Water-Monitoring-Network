package cn.jsu.dao;

import cn.jsu.pojo.web.dto.DeviceInfoVO;
import cn.jsu.pojo.web.dto.QueryDeviceDetailsDTO;
import cn.jsu.pojo.web.dto.QueryDeviceListDTO;
import cn.jsu.pojo.web.entity.City;
import cn.jsu.pojo.web.entity.DeviceInfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author: Lyrcis
 * @date: 2021/10/17
 * @description: 芜湖.
 */

@Mapper
@Repository
public interface DeviceDao {
    /**
     * 检查设备eui是否重复
     * @param deviceEui 设备eui
     * @return 结果
     */
    Integer checkDeviceEuiUnique(String deviceEui);

    /**
     * 检查设备addr是否重复
     * @param deviceAddr 设备addr
     * @return 结果
     */
    Integer checkDeviceAddrUnique(String deviceAddr);


    /**
     * 添加设备信息
     * @param deviceInfo 设备信息
     * @return null
     */
    void addDevice(DeviceInfo deviceInfo);

    /**
     * 更新设备信息
     * @param deviceInfo 设备信息
     * @return null
     */
    void updateDeviceInfo(DeviceInfo deviceInfo);

    /**
     * 删除设备
     * @param deviceIds 设备信息
     * @return null
     */
    void deleteDevice(List<Integer> deviceIds);

    /**
     * 查询设备列表
     * @param queryDeviceListDTO 用户id
     * @return DeviceInfoVO
     */
    List<DeviceInfoVO> queryDeviceList(QueryDeviceListDTO queryDeviceListDTO);

    /**
     * 查询设备基本信息
     * @param deviceId 用户id
     * @return null
     */
    DeviceInfo queryDeviceDetails(@Param("deviceId") Integer deviceId,@Param("userId") Integer userId);

    /**
     * 查询位置
     * @param pid 父类地区id
     * @return 结果
     */
    List<City> queryAddress(Integer pid);

    String queryDeviceIpById(Integer deviceId);

    City queryAddressById(Integer id);

    /**
     * 添加用户设备
     * @param userId 父类地区id
     * @return 结果
     */
    void addUserDevice(@Param("userId")Integer userId,@Param("deviceId")Integer deviceId);
}
