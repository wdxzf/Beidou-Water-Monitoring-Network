package cn.jsu.pojo.web.vo;


import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

/**
 * @Author: shy
 * @Date: 2021/10/19 21:05
 */
public class LoginResponseVo {
    private Integer userId;
    private String userName;
    private String userAccount;
    private String userNickName;
    private String userSex;
    private String userEmail;
    private String userPhone;
    private String Remark;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;
    private Integer delFlag;
    private Integer roleId;

    public LoginResponseVo() {
    }

    public LoginResponseVo(Integer userId, String userName, String userAccount, String userNickName, String userSex, String userEmail, String userPhone, String remark, Date createDate, Integer delFlag, Integer roleId) {
        this.userId = userId;
        this.userName = userName;
        this.userAccount = userAccount;
        this.userNickName = userNickName;
        this.userSex = userSex;
        this.userEmail = userEmail;
        this.userPhone = userPhone;
        Remark = remark;
        this.createDate = createDate;
        this.delFlag = delFlag;
        this.roleId = roleId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserAccount() {
        return userAccount;
    }

    public void setUserAccount(String userAccount) {
        this.userAccount = userAccount;
    }

    public String getUserNickName() {
        return userNickName;
    }

    public void setUserNickName(String userNickName) {
        this.userNickName = userNickName;
    }

    public String getUserSex() {
        return userSex;
    }

    public void setUserSex(String userSex) {
        this.userSex = userSex;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPhone() {
        return userPhone;
    }

    public void setUserPhone(String userPhone) {
        this.userPhone = userPhone;
    }

    public String getRemark() {
        return Remark;
    }

    public void setRemark(String remark) {
        Remark = remark;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Integer getRoleId() {
        return roleId;
    }

    public void setRoleId(Integer roleId) {
        this.roleId = roleId;
    }

    @Override
    public String toString() {
        return "LoginResponseVo{" +
                "userId=" + userId +
                ", userName='" + userName + '\'' +
                ", userAccount='" + userAccount + '\'' +
                ", userNickName='" + userNickName + '\'' +
                ", userSex='" + userSex + '\'' +
                ", userEmail='" + userEmail + '\'' +
                ", userPhone='" + userPhone + '\'' +
                ", Remark='" + Remark + '\'' +
                ", createDate=" + createDate +
                ", delFlag=" + delFlag +
                ", roleId=" + roleId +
                '}';
    }
}
