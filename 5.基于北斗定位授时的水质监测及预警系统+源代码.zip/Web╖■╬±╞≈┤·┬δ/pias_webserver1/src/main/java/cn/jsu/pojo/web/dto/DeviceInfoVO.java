package cn.jsu.pojo.web.dto;

import lombok.Data;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

@Data
public class DeviceInfoVO implements Serializable {
    Integer deviceId;
    String deviceEui;
    String deviceName;
    String deviceAddres;
    List<String> address;
    String deviceType;
    String deviceMark;
    Date createDate;
    Integer deviceAngle;
    String deviceSpecification;
    Integer deviceVoltag;
    Integer devicePower;
    Integer deviceRange;
    Integer addressId;
}
