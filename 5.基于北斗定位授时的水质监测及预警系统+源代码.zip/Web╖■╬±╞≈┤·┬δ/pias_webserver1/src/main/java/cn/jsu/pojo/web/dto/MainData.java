package cn.jsu.pojo.web.dto;

import java.util.Date;

public class MainData {
    Date measureTime;
    Double electricityPower;

    public MainData() {
    }

    public MainData(Date measureTime, Double electricityPower) {
        this.measureTime = measureTime;
        this.electricityPower = electricityPower;
    }

    public Date getMeasureTime() {
        return measureTime;
    }

    public void setMeasureTime(Date measureTime) {
        this.measureTime = measureTime;
    }

    public Double getElectricityPower() {
        return electricityPower;
    }

    public void setElectricityPower(Double electricityPower) {
        this.electricityPower = electricityPower;
    }
}
