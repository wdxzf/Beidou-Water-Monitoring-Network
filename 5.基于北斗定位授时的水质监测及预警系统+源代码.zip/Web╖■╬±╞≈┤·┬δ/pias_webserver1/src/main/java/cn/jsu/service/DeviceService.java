package cn.jsu.service;

import cn.jsu.pojo.net.DeviceInformation;
import cn.jsu.pojo.web.dto.AddDeviceDTO;
import cn.jsu.pojo.web.dto.DeviceInfoVO;
import cn.jsu.pojo.web.dto.QueryDeviceDetailsDTO;
import cn.jsu.pojo.web.dto.QueryDeviceListDTO;
import cn.jsu.pojo.web.entity.City;
import cn.jsu.pojo.web.entity.DeviceInfo;
import cn.jsu.pojo.web.vo.CommonResult;
import io.swagger.models.auth.In;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author: Lyrcis
 * @date: 2021/10/17
 * @description: 芜湖.
 */
public interface DeviceService {

    CommonResult<Object> addDevice(AddDeviceDTO addDeviceDTO);

    void updateDeviceInfo(DeviceInfo deviceInfo);

    void deleteDevice(List<Integer> deviceIds);

    List<DeviceInfoVO> queryDeviceList(QueryDeviceListDTO queryDeviceListDTO);

    DeviceInfo queryDeviceDetails(QueryDeviceDetailsDTO queryDeviceDetailsDTO);

    List<City> queryAddress(Integer pid);

    public  CommonResult<?> TestDataTransmission(DeviceInformation deviceInformation);
}
