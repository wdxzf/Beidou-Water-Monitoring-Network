package cn.jsu.net;


import cn.jsu.config.NettyConfig;
import cn.jsu.heart.HeartClient;
import cn.jsu.net.client.NettyClient;
//import cn.jsu.net.thread.NettyInThread;
import cn.jsu.net.thread.NettyOutThread;
import cn.jsu.parsing.Pack;
import cn.jsu.pojo.net.DataTransmission;
import cn.jsu.service.impl.DeviceServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/**
 * @Auther: suixuexue
 * @Date: 2020/12/25/21:38
 * @Description: 相当于Netty服务端应用的启动类
 */

@Component
public class NettyServerApplication
{
    @Autowired
    NettyConfig nettyConfig;
    @Autowired
    NettyClient nettyClient;
    @Autowired
    NettyOutThread nettyOutThread;
    @Autowired
    DeviceServiceImpl deviceService;



    /**
     * 需要修改 这里是用来给创建外线线程的BlockingQueue的
     * */
    private static LinkedBlockingQueue<Pack> queueOut;

    public void run()
    {
        //创建并装载外写线程需要用到的队列
        loadResource();
        /**
         * @description 客户端启动
         *              Netty客户端只有读的处理没有写的处理
         */
        new Thread(() ->
        {
            startNetty();
        }, "NettyServer").start();

        try
        {
            //我猜这里睡五秒的原因是要等netty客户端启动完毕
            TimeUnit.SECONDS.sleep(5);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        /**
         * @description 将业务中的信息发出去的线程写处理的 核心代码是 channel.writeAndFlush(xxx);
         */
        new Thread(() ->
        {
            nettyOutThread.run();
        }, "nettyOutThread").start();

        /**
         * @description 心跳包客户端
         */
        new Thread(() -> {
           new HeartClient().run();
        },"HeartThread" ).start();
    }

    private void startNetty()
    {
        //这里拿到的是配置文件中写下的IP和端口
        //上面用线程的原因是Netty需要额外线程 这样同时干两件事嘛
        nettyClient.setIp(nettyConfig.getIp());
        nettyClient.setPort(nettyConfig.getPort());
        nettyClient.connect();
    }

    /**
     * @description 装载外写需要的数据
     * 将这里创建的外写queue  塞给markService 和 fileService
     * 这里三个类用的是同一个阻塞队列
     */
    private void loadResource()
    {

        queueOut = new LinkedBlockingQueue<>();
        nettyOutThread.setQueueOut(queueOut);
        /**
         * 这里需要修改 加上服务层中需要改成需要用来发送信息的 Service
         * */
        deviceService.setLinkedBlockingQueue(queueOut);
    }



}
