package cn.jsu.controller;

import cn.jsu.pojo.web.vo.LoginVo;
//import cn.jsu.pojo.web.dto.UserInformation;
import cn.jsu.pojo.web.vo.CommonResult;
import cn.jsu.service.UserService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserService userService;

    @PostMapping("/login")
    @ApiOperation("登录")
    public CommonResult<Object> login(@RequestBody LoginVo loginVo , HttpServletRequest request){
        System.out.println("email:"+loginVo.getUserEmail());
        System.out.println(loginVo);
        return userService.login(loginVo , request);
    }

    @PostMapping("/queryUserId")
    @ApiOperation("查询userId")
    public CommonResult<Object> queryUserId(@RequestBody LoginVo loginVo ){
        System.out.println("query email:"+loginVo.getUserEmail());
        System.out.println(loginVo);
        return  new CommonResult<>(200,"查询成功",userService.queryUserId(loginVo));
    }

}
