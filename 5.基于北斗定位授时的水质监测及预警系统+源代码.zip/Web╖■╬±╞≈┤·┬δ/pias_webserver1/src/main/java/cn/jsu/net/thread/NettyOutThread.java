package cn.jsu.net.thread;


import cn.jsu.config.NettyConfig;
import cn.jsu.net.client.NettyClientInHandler;
import cn.jsu.parsing.Pack;
import cn.jsu.pojo.net.DataTransmission;
import cn.jsu.pojo.net.WebCheckInfo;
import io.netty.channel.Channel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author: suixuexue
 * @date: 2020/12/30 17:22
 * describe:  serviceImpl中的方法 将QuestionTaskInformation Put进阻塞队列中
 *             就会发送（在阻塞队列没满的情况下）
 */


@Component
public class NettyOutThread implements Runnable
{
    @Autowired
    NettyConfig nettyConfig;

    @Autowired
    WebCheckInfo checkInfo;

    /**
     * 这里需要修改  自己设置需要传输的实体类
    * */
    private LinkedBlockingQueue<Pack> queueOut;

    public void setQueueOut(LinkedBlockingQueue<Pack> queueOut)
    {
        this.queueOut = queueOut;
    }

    @Override
    public void run()
    {
        Pack pack = null;
        byte[] serialize = null;
        Channel channel = NettyClientInHandler.getChannel();

        System.out.println("准备开启外写线程");

        while (true)
        {
            System.out.println("外写线程开始运行.....");
            try
            {
                pack  = queueOut.take();
                System.out.println("拿到数据尝试外写...." + pack.toString());
                serialize = pack.serialize();
                if (channel == null)
                {
                    System.out.println("数据收集服务器已断开");
                    break;
                }
                System.out.println(pack);
                channel.writeAndFlush(serialize);
            }
            catch (InterruptedException e)
            {
                e.printStackTrace();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}
