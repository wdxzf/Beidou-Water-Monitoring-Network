//package cn.jsu.utils;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.redis.core.RedisTemplate;
//import org.springframework.data.redis.support.atomic.RedisAtomicLong;
//import org.springframework.stereotype.Component;
//
///**
// * @Author: wws
// * describe:
//*/
//@Component
//public class RedisUtil {
//
//    @Autowired
//    private RedisTemplate<String, Object> redisTemplate;
//
//    private final int FCNT_MAX = 65536;//FCNT_MAX FCNT最大值
//
//    /**
//     * 删除key
//     * @param key
//     * @return
//     */
//    public void deleteKey(String key) {
//        redisTemplate.delete(key);
//    }
//
//
//    /**
//     * 自增
//     * @param key
//     * @return
//     */
//    public long generate(String key) {
//        RedisAtomicLong counter = new RedisAtomicLong(key, redisTemplate.getConnectionFactory());
//        return counter.incrementAndGet();
//    }
//
//
//
//    /**
//     * 获得FHDR的帧计数器
//     * @return 结果
//     */
//    public byte[] getFhdrFCnt(String key) {
//        String v = redisTemplate.boundValueOps(key).get().toString();
//        return  ToolUtil.FCNTToBytes( Long.parseLong(v) % FCNT_MAX);
//    }
//
//
//
//    /**
//     * 获得FRMPayload的帧计数器
//     * @return 结果
//     */
//    public byte[] getFRMPayloadFCnt(String key) {
//        RedisAtomicLong counter = new RedisAtomicLong(key, redisTemplate.getConnectionFactory());
//        return ToolUtil.FCNTToBytes( counter.incrementAndGet() % FCNT_MAX);
//    }
//
//}
