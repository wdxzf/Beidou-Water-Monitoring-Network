package cn.jsu.pojo.web.entity;

import java.io.Serializable;

public class UserDevice implements Serializable {
    Integer udId;
    Integer userId;
    Integer deviceId;

    public UserDevice(Integer udId, Integer userId, Integer deviceId) {
        this.udId = udId;
        this.userId = userId;
        this.deviceId = deviceId;
    }

    public Integer getUdId() {
        return udId;
    }

    public void setUdId(Integer udId) {
        this.udId = udId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    @Override
    public String toString() {
        return "UserDevice{" +
                "udId=" + udId +
                ", userId=" + userId +
                ", deviceId=" + deviceId +
                '}';
    }
}
