package cn.jsu.pojo.web.dto;

public class QueryDeviceDetailsDTO {
    Integer usrId;
    Integer deviceId;

    public QueryDeviceDetailsDTO() {
    }

    public QueryDeviceDetailsDTO(Integer usrId, Integer deviceId) {
        this.usrId = usrId;
        this.deviceId = deviceId;
    }

    public Integer getUsrId() {
        return usrId;
    }

    public void setUsrId(Integer usrId) {
        this.usrId = usrId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    @Override
    public String toString() {
        return "queryDeviceDetailsDTO{" +
                "usrId=" + usrId +
                ", deviceId=" + deviceId +
                '}';
    }
}
