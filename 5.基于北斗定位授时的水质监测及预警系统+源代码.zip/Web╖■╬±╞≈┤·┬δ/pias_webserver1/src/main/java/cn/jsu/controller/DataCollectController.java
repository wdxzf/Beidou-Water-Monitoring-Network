package cn.jsu.controller;

import cn.jsu.pojo.web.dto.*;
import cn.jsu.pojo.web.entity.LocateInfo;
import cn.jsu.pojo.web.vo.CommonResult;
import cn.jsu.service.DataCollectService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author: Lyrcis
 * @date: 2021/9/20
 * @description: 芜湖.
 */

@CrossOrigin
@RestController
@RequestMapping("/dataCollect")
public class DataCollectController {
    @Autowired
    DataCollectService dataCollectService;

    /**
     * @author Lyrcis
     * @param dataQuery ss
     * @return CommonResult
     */
    @PostMapping("/queryPower")
    @ApiOperation("查询电功率")
    public CommonResult<Object> querryPower(@RequestBody DataQuery dataQuery) {
        MainDataDTO bigDecimals = dataCollectService.queryPower(dataQuery);
        return new CommonResult<>(200, "query power successfully!",bigDecimals);
    }

    @PostMapping("/queryNowPower")
    @ApiOperation("查询实时电功率")
    public CommonResult<Object> queryNowPower(@RequestBody QueryInfo queryInfo) {
        MainDataDTO bigDecimals = dataCollectService.queryNowPower(queryInfo);
        return new CommonResult<>(200, "query power successfully!",bigDecimals);
    }
    /**
     * @author Lyrcis
     * @param dataQuery ss
     * @return CommonResult
     */
    @PostMapping("/queryExtraData")
    @ApiOperation("查询温湿度")
    public CommonResult<Object> querryExtraData(@RequestBody DataQuery dataQuery) {
        ExtraDataDTO extraDatas = dataCollectService.queryExtraData(dataQuery);
        return new CommonResult<>(200, "query extradata successfully!",extraDatas);
    }

    @PostMapping("/queryNowExtraData")
    @ApiOperation("查询当前温湿度")
    public CommonResult<Object> queryNowExtraData(@RequestBody QueryInfo queryInfo) {
        ExtraDataDTO extraDatas = dataCollectService.queryNowExtraData(queryInfo);
        return new CommonResult<>(200, "query extradata successfully!",extraDatas);
    }


    /**
     * @author Lyrcis
     * @param deviceId ss
     * @return CommonResult
     */
    @PostMapping("/queryLocate")
    @ApiOperation("查询经纬度")
    public CommonResult<Object> queryCoordinate(@RequestBody Integer deviceId) {
        LocateInfo locateInfo = dataCollectService.queryLocate(deviceId);
        return new CommonResult<>(200, "query LocateData successfully!",locateInfo);
    }


    /**
     * @author Lyrcis
     * @param deviceId sss
     * @return CommonResult
     */
    @PostMapping("/queryPDataCount")
    @ApiOperation("查询光伏数据提交次数（日历图）")
    public CommonResult<Object> queryPowerDataCount(@RequestBody Integer deviceId) {
        Map<String, Object> count = dataCollectService.getPowerDataCount(deviceId);
        return new CommonResult<>(200, "query LocateData successfully!",count);
    }


}
