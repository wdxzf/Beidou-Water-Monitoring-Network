package cn.jsu;

import cn.jsu.net.NettyServerApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


@SpringBootApplication
public class WebServerApplication  extends SpringBootServletInitializer implements CommandLineRunner {
//extends SpringBootServletInitializer

    @Autowired
    private NettyServerApplication nettyServerApplication;

//    public static void main(String[] args) {
//        SpringApplication.run(WebServerApplication.class,args);
//    }

    /**
     * @description netty客户端
    * */
    @Override
    public void run(String... args) throws Exception {
        nettyServerApplication.run();
    }
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(WebServerApplication.class);
    }
}
