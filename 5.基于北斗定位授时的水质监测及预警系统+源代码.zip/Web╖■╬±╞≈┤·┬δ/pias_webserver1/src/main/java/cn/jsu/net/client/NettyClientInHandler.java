package cn.jsu.net.client;


import cn.jsu.config.ResourceConfig;
import cn.jsu.heart.HeartClient;
import cn.jsu.heart.HeartInformation;
import cn.jsu.parsing.Pack;
import cn.jsu.pojo.net.WebCheckInfo;
import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelInboundHandlerAdapter;
import lombok.extern.slf4j.Slf4j;

import java.net.InetSocketAddress;

/**
 * @author: suixuexue
 * @date: 2020/11/4 20:43
 * describe:
 *  客户端主要业务逻辑的处理
 *  这里只有一个channel的原因是 客户端只会连接一个服务器
 *  所以只需要维护一个channel
 *  这个类中的channel由 开始连接时赋进来
 *
 *  客户端创建的时候 还有 调用外写线程的时候
 *  会取到这个类中的channel
 *    NettyClientInHandler.getChannel().writeAndFlush(heartInformation.serialize());
 *
 */

@Slf4j
public class NettyClientInHandler extends ChannelInboundHandlerAdapter {
    //这里的channel是在客户端连接服务器时拿到的channel  在建立连接的时候赋进来的
    private static Channel channel;

    public static Channel getChannel() {
        return channel;
    }

    public static void setChannel(Channel channel) {
        NettyClientInHandler.channel = channel;
    }


    /**
    * @Description: 建立连接的时候触发这个方法，完成相应的业务逻辑，作为客户端主动去连接上位机一旦建立连接就向上位机发送心跳信息，在这之前建立
     * 对应这个连接的心跳计时的线程，用于确定这两台服务器之间都能够是完好的
     *              做了两件事 发送验证包和心跳
    * @Params:
    * @Return
    */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        channel = ctx.channel();
        WebCheckInfo checkInfo = new WebCheckInfo(ResourceConfig.getConfigString("net.client.web.connect.password"));
        channel.writeAndFlush(checkInfo.serialize());

        HeartInformation heartInformation = new HeartInformation();
        ctx.channel().writeAndFlush(heartInformation.serialize());
        ctx.fireChannelActive();//如果没有这句，读事件将不会触发
        super.channelActive(ctx);
    }

    /**
    * @Description: 建立连接的时候为将对应这个连接的ip地址存放在全局的map中，并且为这个连接创建心跳计时线程
    * @Params:
    * @Return
    */


    /**
     * @Description: 通过这个方法从传递进来的参数中获得对应的ip地址以及端口号，并且保证ip地址存放在返回值位置为0的数组位置
     *               在Netty服务器中这个方法被写在了NetUtil中
     * @Params: ChannelHandler 和 ChannelPipeline 之间的关联。
     * @Return ip地址以String形式，端口号也以String的形式存放，端口号存在位置为1的数组中
     */

    public Object[] getIPAndPort(ChannelHandlerContext ctx){
        Object[] objects = new Object[2];
        InetSocketAddress inetSocketAddress = (InetSocketAddress) ctx.channel().remoteAddress();
        objects[0] = inetSocketAddress.getAddress().getHostAddress();//获取ip
        objects[1] = inetSocketAddress.getPort();//端口号
        return objects;
    }


    /**
     * 断开连接时触发的方法
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        Object[] ipAndPort = getIPAndPort(ctx);
        ctx.channel().close();
        ctx.close();
//        System.out.println("此时已经移除map中的Channel......");
        log.debug("下位机断开连接，断开连接的下位机ip地址为"+ipAndPort[0]+",端口号为"+ipAndPort[1]+"。由于断开连接，将此ip地址从全局map中移除");
    }

    /**
     * 当客户端读取到来自服务端的代码时触发的方法,本機作爲下位機主動去鏈接Web服務器，儅接受到Web服務器傳遞過來的數據之後觸發這個方法
     * 部分字節數組的内容的解析是在這個地方進行的，此時有兩種處理方式，第一種處理方式是在這裏，第二種是專門在ClientInThread中處理相關的數據解析
     * 在設計的時候是打算大部分數據都在專門的解析綫程中處理的，但是後來發現部分數據需要在這裏進行處理，例如心跳包，避免數據的阻塞，後續可能還會對
     * 所有的内容重新進行解析，偏向於各施其職，也就是數據解析的綫程專門用於處理數據的解析，這樣才是合適的。
     * 目前將部分數據丟于這裏進行解析的條件在於對於部分數據列如心跳數據，基本上沒有和心跳包一樣的長的字節數組，或者説是很少有等長的字節數組，對於這
     * 種很少的字節數組來説，判斷一下長度，在長度後面在判斷一下包頭即可，并不是很複雜的操作，但是對於性能是有一部分的影響的，所以偏向於各司其職
     * @param ctx 在ChannelHandler添加到ChannelPipeline時會創建一個實例，就是接口ChannelHandlerContext，代表了ChannelHandler與
     * ChannelPipeline之間的關聯
     * @param msg 相當於出發Read方法時讀取到的字節數組
     * @throws Exception
     */
    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
        Pack pack = (Pack)msg;

        if (pack.getTypeNo() == 88)
        {
            HeartClient.isHeart = true;
        }

        super.channelRead(ctx,msg);
//        //log.debug("读取到一个上位机传递过来的任务数据");
//        Object[] ipAndPort = getIPAndPort(ctx);
//        int l =  ((byte[]) msg).length;
//        Object o = null;
//        if ((l == HLENGTH)) {
//            o = heartInfoJudge.heartProcessing((String) ipAndPort[0], msg);
//            if (o != null){
//                heartThreadSet.changeStatue((String) ipAndPort[0], (HeartInformationPack)o, ctx.channel());
//            }
//        }
//        if (o == null){//如果返回的值不等于null表示发送的内容确实是心跳包,也确实不是基本信息数据包
//            queueIn.put(msg);//将消息字节数组添加到隊列中，此時添加的消息包含了很多，最主要的内容為判題任務信息，在整個系統中，判題任務信息又分爲兩種第一種是指包含測試樣例的判題任務信息，第二種是不包含測試樣例的判題任務信息
//            //log.debug("将从上位机传递的判题任务数据存放到数据解析的缓存队列当中");
//            //System.out.println(queueIn.size()+"缓存队列大小为");
//        }else {
//        }
    }

    /**
     * 读完成时触发的方法
     * @param ctx
     * @throws Exception
     */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) throws Exception {

    }
}
