package cn.jsu.service.impl;

import cn.jsu.dao.UserDao;
import cn.jsu.pojo.web.vo.LoginResponseVo;
import cn.jsu.pojo.web.vo.LoginVo;
//import cn.jsu.pojo.web.dto.UserInformation;
import cn.jsu.pojo.web.vo.CommonResult;
import cn.jsu.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserDao userDao;

//    @Override
//    public int regist(UserInformation userInfo) {
//        int i = userDao.queryEmail(userInfo.getUserEmail());
//        if(i>0){
//            return 1;
//        }
//        int i1 = userDao.insertUserInfo(userInfo);
//        if(i1>0){
//            return 2;
//        }
//        return 0;
//    }

    @Override
    public CommonResult<Object> login(LoginVo loginVo, HttpServletRequest request) {
        HttpSession session = request.getSession();
        try {
            LoginResponseVo responseVo = userDao.login(loginVo);
            if(!responseVo.equals("") || !responseVo.equals("null")){
                return new CommonResult<>(200,"登录成功",responseVo);
            }
        }catch (Exception e){
            return new CommonResult<>(444,"登录失败");
        }
        return null;
    }

    @Override
    public Integer queryUserId(LoginVo loginVo) {
        return userDao.queryUserId(loginVo);
    }

}
