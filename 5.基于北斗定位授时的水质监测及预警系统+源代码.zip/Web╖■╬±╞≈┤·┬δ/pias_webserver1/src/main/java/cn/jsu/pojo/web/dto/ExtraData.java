package cn.jsu.pojo.web.dto;

import java.math.BigDecimal;
import java.sql.Date;

public class ExtraData {
    Date measureTime;
    Double dataTemperature;
    Double dataHumidity;

    public ExtraData() {
    }

    public ExtraData(Date measureTime, Double dataTemperature, Double dataHumidity) {
        this.measureTime = measureTime;
        this.dataTemperature = dataTemperature;
        this.dataHumidity = dataHumidity;
    }

    public Date getMeasureTime() {
        return measureTime;
    }

    public void setMeasureTime(Date measureTime) {
        this.measureTime = measureTime;
    }

    public Double getDataTemperature() {
        return dataTemperature;
    }

    public void setDataTemperature(Double dataTemperature) {
        this.dataTemperature = dataTemperature;
    }

    public Double getDataHumidity() {
        return dataHumidity;
    }

    public void setDataHumidity(Double dataHumidity) {
        this.dataHumidity = dataHumidity;
    }

    @Override
    public String toString() {
        return "ExtraData{" +
                "measureTime=" + measureTime +
                ", dataTemperature=" + dataTemperature +
                ", dataHumidity=" + dataHumidity +
                '}';
    }
}
