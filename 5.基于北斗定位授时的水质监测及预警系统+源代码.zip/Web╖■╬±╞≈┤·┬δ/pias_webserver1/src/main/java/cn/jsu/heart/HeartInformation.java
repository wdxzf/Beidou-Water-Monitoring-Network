package cn.jsu.heart;


import cn.jsu.parsing.Pack;
import cn.jsu.parsing.PackType;

@PackType(typeNo = 88)
public class HeartInformation extends Pack {

}