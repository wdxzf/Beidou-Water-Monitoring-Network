package cn.jsu.utils.util;

import io.netty.channel.Channel;

import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;

/**
 * @author ahtonc
 */
public class NetUtil {
    public static Object[] getIPAndPort(Channel channel){
        Object[] objects = new Object[2];
        InetSocketAddress inetSocketAddress = (InetSocketAddress) channel.remoteAddress();
        //获取ip
        objects[0] = inetSocketAddress.getAddress().getHostAddress();
        //端口号
        objects[1] = inetSocketAddress.getPort();
        return objects;
    }

    public static String getIP(Channel channel){
        Object[] objects = getIPAndPort(channel);
        return objects[0].toString();
    }

    public static String getHostAddress() {
        try {
            return Inet4Address.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
        return null;
    }
}
