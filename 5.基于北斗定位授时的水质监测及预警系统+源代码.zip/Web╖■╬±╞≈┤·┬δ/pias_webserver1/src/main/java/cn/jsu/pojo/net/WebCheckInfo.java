package cn.jsu.pojo.net;


import cn.jsu.parsing.Pack;
import cn.jsu.parsing.PackType;
import org.springframework.stereotype.Component;

/**
 * @author 24987
 */
@Component
@PackType(typeNo = 2)
public class WebCheckInfo extends Pack {

    private String checkPwd;

    public WebCheckInfo() {
    }

    public WebCheckInfo(String checkPwd) {
        this.checkPwd = checkPwd;
    }

    public String getCheckPwd() {
        return checkPwd;
    }

    public void setCheckPwd(String checkPwd) {
        this.checkPwd = checkPwd;
    }

    @Override
    public String toString() {
        return "WebCheckInfo{" +
                "checkPwd='" + checkPwd + '\'' +
                '}';
    }
}
