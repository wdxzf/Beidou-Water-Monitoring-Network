package cn.jsu.net.client;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;
import org.springframework.stereotype.Component;

/**
 * @author: suixuexue
 * @date: 2020/11/4 20:41
 * describe:
 */

@Component
public class NettyClient {

    private String ip;
    private int port;


    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    /**
    * @Description: 连接上位机
    * @Params:
    * @Return
    */
    public void connect(){
        boolean connectFlag = true;
        ChannelFuture channelFuture = null;
        NioEventLoopGroup event = new NioEventLoopGroup();//事件循环组
        try {
            Bootstrap bootstrap = new Bootstrap();//客户端启动对象

            bootstrap.group(event)//将事件循环组添加进启动对象
                    .channel(NioSocketChannel.class)//指定客户端采用通道的类型
                    .option(ChannelOption.SO_KEEPALIVE, true)
                    .handler(new NettyClientInit());//指定客户端的初始化需要加载的处理器

            //启动客户端，连接服务器
            channelFuture = bootstrap.connect(ip, port).sync();

            connectFlag = channelFuture.isSuccess();

            channelFuture.channel().closeFuture().sync();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }finally {
            event.shutdownGracefully();
            connectFlag = false;
            //System.out.println("断开连接++++++++++++++++++++++++++++++++++++++++++++++++++++++++++");
        }

    }

    public void reConnect() {
        connect();
    }
}