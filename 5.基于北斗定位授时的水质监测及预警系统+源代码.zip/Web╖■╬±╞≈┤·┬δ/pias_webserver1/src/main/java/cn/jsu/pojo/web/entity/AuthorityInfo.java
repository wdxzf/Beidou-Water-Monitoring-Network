package cn.jsu.pojo.web.entity;

import java.io.Serializable;

public class AuthorityInfo implements Serializable {
    Integer apiId;
    String apiName;
    String apiDescription;
    String apiUrl;
    String apiMethod;

    public AuthorityInfo(Integer apiId, String apiName, String apiDescription, String apiUrl, String apiMethod) {
        this.apiId = apiId;
        this.apiName = apiName;
        this.apiDescription = apiDescription;
        this.apiUrl = apiUrl;
        this.apiMethod = apiMethod;
    }

    public Integer getApiId() {
        return apiId;
    }

    public void setApiId(Integer apiId) {
        this.apiId = apiId;
    }

    public String getApiName() {
        return apiName;
    }

    public void setApiName(String apiName) {
        this.apiName = apiName;
    }

    public String getApiDescription() {
        return apiDescription;
    }

    public void setApiDescription(String apiDescription) {
        this.apiDescription = apiDescription;
    }

    public String getApiUrl() {
        return apiUrl;
    }

    public void setApiUrl(String apiUrl) {
        this.apiUrl = apiUrl;
    }

    public String getApiMethod() {
        return apiMethod;
    }

    public void setApiMethod(String apiMethod) {
        this.apiMethod = apiMethod;
    }

    @Override
    public String toString() {
        return "AuthorityInfo{" +
                "apiId=" + apiId +
                ", apiName='" + apiName + '\'' +
                ", apiDescription='" + apiDescription + '\'' +
                ", apiUrl='" + apiUrl + '\'' +
                ", apiMethod='" + apiMethod + '\'' +
                '}';
    }
}
