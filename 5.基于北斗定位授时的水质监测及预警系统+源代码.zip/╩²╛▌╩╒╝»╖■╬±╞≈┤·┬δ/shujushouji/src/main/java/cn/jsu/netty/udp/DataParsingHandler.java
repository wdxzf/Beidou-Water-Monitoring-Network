package cn.jsu.netty.udp;

import cn.jsu.dao.DeviceDao;
import cn.jsu.pojo.*;
import cn.jsu.utils.ParsingUtil;
import com.google.common.primitives.Bytes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.net.DatagramPacket;
import java.text.DecimalFormat;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.LinkedBlockingQueue;
import lombok.extern.slf4j.Slf4j;

/**
 * @author: lyx
 * @date: 2021/09/19/21:58
 * describe:
 **/
@Component
@Slf4j
public class DataParsingHandler implements Runnable{
    private LinkedBlockingQueue<DatagramPacket> queue;

    @Autowired
    DeviceDao deviceDao;

    public void setQueue(LinkedBlockingQueue<DatagramPacket> queue) {
        this.queue = queue;
    }

    @Override
    public void run() {
        for (; ; ) {
            try {
                //取出queue中的包，没有则阻塞
                DatagramPacket packet = queue.take();
                log.info("来自IP"+packet.getAddress().getHostAddress()+":"+packet.getPort()+"的数据");
                byte[] data = Arrays.copyOfRange(packet.getData(), 0, packet.getLength());

                System.out.println(Arrays.toString(data));

                //验证数据包合理性
                if (!ParsingUtil.checkPacket(data)) {
                    log.info("错误的数据包");
                    continue;
                }
                PushDataPacket pushDataPacket = ParsingUtil.getPushDataPacket(data);
                log.info("设备Eui"+pushDataPacket.getDeviceEui()+"-----"+getPackTypeString(data[0]));
                System.out.println(pushDataPacket);
                Integer deviceId = deviceDao.selectDeviceByEui(pushDataPacket.getDeviceEui());
                if(deviceId==null){
                    log.info("未注册的设备");
                    continue;
                }

                switch (data[0]) {
                    case 0x01:
                        pushElectricPowerData(deviceId,pushDataPacket);
                        break;
                    case 0x02:
                        pushTemperatureAndHumidity(deviceId,pushDataPacket);
                        break;
                    case 0x03:
                        pushBatteryVoltage(deviceId,pushDataPacket);
                        break;
                    case 0x05:
                        pushLocationData(deviceId,pushDataPacket);
                        break;
                    default:
                        System.out.println("Packet type error");
                        continue;

                }
            } catch (Exception e) {
                e.printStackTrace();
                return;
            }
        }
    }

    private void pushElectricPowerData(Integer deviceId,PushDataPacket pushDataPacket){
        float electricCurrent = pushDataPacket.getFirstFloatData();
        float electricTension = pushDataPacket.getSecondFloatData();
        DataInfo dataInfo = new DataInfo(deviceId,Date.from(new Date().toInstant()),BigDecimal.valueOf(electricCurrent*electricTension));

        deviceDao.insertElectricData(dataInfo);
    }

    private void pushTemperatureAndHumidity(Integer deviceId,PushDataPacket pushDataPacket){
        BigDecimal wenDu = BigDecimal.valueOf(pushDataPacket.getFirstFloatData());
        BigDecimal shiDu = BigDecimal.valueOf(pushDataPacket.getSecondFloatData());
        ExtraDataInfo extraDataInfo = new ExtraDataInfo(deviceId,Date.from(new Date().toInstant()),wenDu
                ,shiDu);

        deviceDao.insertTemperatureAndHumidity(extraDataInfo);
    }

    private void pushBatteryVoltage(Integer deviceId,PushDataPacket pushDataPacket){
        LithiumBatteryInfo lithiumBatteryInfo = new LithiumBatteryInfo(deviceId,Date.from(new Date().toInstant()),BigDecimal.valueOf(pushDataPacket.getFirstFloatData()));

        deviceDao.insertBatteryVoltageInfo(lithiumBatteryInfo);
    }

    private void pushLocationData(Integer deviceId,PushDataPacket pushDataPacket){
        Double longitude = jinDuJiSua(pushDataPacket.getFirstFloatData());
        Double latitude = weiDuJiSua(pushDataPacket.getSecondFloatData());
        LocateInfo locateInfo = new LocateInfo(deviceId,Date.from(new Date().toInstant()),
                longitude,latitude);

        deviceDao.insertLocateInfo(locateInfo);
    }

    private Double jinDuJiSua(float longitude){
        int diYi = (int) (longitude/ 100);
        DecimalFormat format = new DecimalFormat("#.0000");
        String scaled = format.format(longitude - diYi * 100);
        float v = Float.parseFloat(scaled);
        return diYi + (v / 60.00);
    }

    private Double weiDuJiSua(float longitude){
        int diYi = (int) (longitude/ 100);
        DecimalFormat format = new DecimalFormat("#.0000");
        String scaled = format.format(longitude - diYi * 100);
        float v = Float.parseFloat(scaled);
        System.out.println(v);
        return diYi + (v / 60.00);
    }

    private static String getPackTypeString(Byte b){
        switch (b){
            case 0x01:
                return "光伏数据";
            case 0x02:
                return "温湿度数据";
            case 0x06:
                return "锂电池数据";
            default:
                return "未知数据";
        }
    }
}
