package cn.jsu.pojo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author: lyx
 * @date: 2021/09/20/00:05
 * describe:
 **/
public class DataInfo {
    private Integer dataId;
    private Integer deviceId;
    private Date measureTime;
    private BigDecimal electricityPower;

    public DataInfo() {
    }

    public DataInfo(Integer deviceId, Date measureTime, BigDecimal electricityPower) {
        this.deviceId = deviceId;
        this.measureTime = measureTime;
        this.electricityPower = electricityPower;
    }

    public DataInfo(Integer dataId, Integer deviceId, Date measureTime, BigDecimal electricityPower) {
        this.dataId = dataId;
        this.deviceId = deviceId;
        this.measureTime = measureTime;
        this.electricityPower = electricityPower;
    }

    public Integer getDataId() {
        return dataId;
    }

    public void setDataId(Integer dataId) {
        this.dataId = dataId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Date getMeasureTime() {
        return measureTime;
    }

    public void setMeasureTime(Date measureTime) {
        this.measureTime = measureTime;
    }


    public BigDecimal getElectricityPower() {
        return electricityPower;
    }

    public void setElectricityPower(BigDecimal electricityPower) {
        this.electricityPower = electricityPower;
    }

    @Override
    public String toString() {
        return "DataInfo{" +
                "dataId=" + dataId +
                ", deviceId=" + deviceId +
                ", measureTime=" + measureTime +
                ", electricityPower=" + electricityPower +
                '}';
    }
}
