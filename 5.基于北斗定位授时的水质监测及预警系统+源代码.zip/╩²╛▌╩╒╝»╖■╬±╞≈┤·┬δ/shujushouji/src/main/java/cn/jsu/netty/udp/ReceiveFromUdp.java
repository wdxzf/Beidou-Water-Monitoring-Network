package cn.jsu.netty.udp;

import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author lyx
 * @date 2021/09/19 21:21
 * 用于接收设备数据，并把接受到的数据放入receiveFromUdpQueue
 */
@Component
public class ReceiveFromUdp implements Runnable {

    private DatagramSocket udpSocket;
    public  LinkedBlockingQueue<DatagramPacket> receiveFromUdpQueue;

    public void setUdpSocket(DatagramSocket udpSocket) {
        this.udpSocket = udpSocket;
    }

    public void setReceiveFromUdpQueue(LinkedBlockingQueue<DatagramPacket> receiveFromUdpQueue) {
        this.receiveFromUdpQueue = receiveFromUdpQueue;
    }

    @Override
    public void run() {
        try {

            while (true){
                byte[] data = new byte[1024 * 2];
                DatagramPacket datagramPacket= new DatagramPacket(data, data.length);
                //接受数据包
                udpSocket.receive(datagramPacket);
                //将数据包存入GWDataParsingThreadQueue中
                receiveFromUdpQueue.put(datagramPacket);
            }
        } catch (IOException | InterruptedException e) {
            System.out.println("接收数据失败");
            e.printStackTrace();
        }
    }
}
