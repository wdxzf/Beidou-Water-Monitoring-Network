package cn.jsu.netty;

import cn.jsu.netty.udp.DataParsingHandler;
import cn.jsu.netty.udp.ReceiveFromUdp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author: lyx
 * @date: 2021/09/19/21:24
 * describe:
 **/
@Component
public class NettyServerApplication {
    @Autowired
    ReceiveFromUdp receiveFromUdp;

    @Autowired
    DataParsingHandler dataParsingHandler;

    private static LinkedBlockingQueue<DatagramPacket> queue;


    public void run() throws SocketException {
        DatagramSocket udpSocket = new DatagramSocket(7777);
        queue = new LinkedBlockingQueue<>();
        receiveFromUdp.setReceiveFromUdpQueue(queue);
        receiveFromUdp.setUdpSocket(udpSocket);

        dataParsingHandler.setQueue(queue);
        System.out.println("通信行程跑起来了");
        new Thread(()->{
            receiveFromUdp.run();
        },"UdpClient").start();
        new Thread(()->{
            dataParsingHandler.run();
        },"UdpClient").start();
    }
}
