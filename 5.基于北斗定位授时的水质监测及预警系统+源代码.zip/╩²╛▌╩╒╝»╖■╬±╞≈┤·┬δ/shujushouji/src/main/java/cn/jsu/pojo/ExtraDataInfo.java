package cn.jsu.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

public class ExtraDataInfo implements Serializable {
    Integer dataId;
    Integer deviceId;
    Date measureTime;
    BigDecimal dataTemperature;
    BigDecimal dataHumidity;

    public ExtraDataInfo() {
    }

    public ExtraDataInfo(Integer deviceId, Date measureTime, BigDecimal dataTemperature, BigDecimal dataHumidity) {
        this.deviceId = deviceId;
        this.measureTime = measureTime;
        this.dataTemperature = dataTemperature;
        this.dataHumidity = dataHumidity;
    }

    public ExtraDataInfo(Integer dataId, Integer deviceId, Timestamp measureTime, BigDecimal dataTemperature, BigDecimal dataHumidity) {
        this.dataId = dataId;
        this.deviceId = deviceId;
        this.measureTime = measureTime;
        this.dataTemperature = dataTemperature;
        this.dataHumidity = dataHumidity;
    }

    public Integer getDataId() {
        return dataId;
    }

    public void setDataId(Integer dataId) {
        this.dataId = dataId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Date getMeasureTime() {
        return measureTime;
    }

    public void setMeasureTime(Date measureTime) {
        this.measureTime = measureTime;
    }

    public BigDecimal getDataTemperature() {
        return dataTemperature;
    }

    public void setDataTemperature(BigDecimal dataTemperature) {
        this.dataTemperature = dataTemperature;
    }

    public BigDecimal getDataHumidity() {
        return dataHumidity;
    }

    public void setDataHumidity(BigDecimal dataHumidity) {
        this.dataHumidity = dataHumidity;
    }

    @Override
    public String toString() {
        return "ExtraDataInfo{" +
                "dataId=" + dataId +
                ", deviceId=" + deviceId +
                ", measureTime=" + measureTime +
                ", dataTemperature=" + dataTemperature +
                ", dataHumidity=" + dataHumidity +
                '}';
    }
}
