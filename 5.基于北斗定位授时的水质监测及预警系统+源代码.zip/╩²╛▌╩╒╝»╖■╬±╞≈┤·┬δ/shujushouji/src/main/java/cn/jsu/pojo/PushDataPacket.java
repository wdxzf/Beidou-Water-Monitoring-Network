package cn.jsu.pojo;

import java.util.Date;

/**
 * @author: lyx
 * @date: 2021/09/20/15:12
 * describe:
 **/
public class PushDataPacket {
    private String deviceEui;
    /**
     * 电流值
     */
    private float firstFloatData;
    /**
     * 电压值
     */
    private float secondFloatData;
    private Date measureTime;

    public PushDataPacket() {
    }

    public PushDataPacket(String deviceEui, float firstFloatData, float secondFloatData, Date measureTime) {
        this.deviceEui = deviceEui;
        this.firstFloatData = firstFloatData;
        this.secondFloatData = secondFloatData;
        this.measureTime = measureTime;
    }

    public String getDeviceEui() {
        return deviceEui;
    }

    public void setDeviceEui(String deviceEui) {
        this.deviceEui = deviceEui;
    }

    public float getFirstFloatData() {
        return firstFloatData;
    }

    public void setFirstFloatData(float firstFloatData) {
        this.firstFloatData = firstFloatData;
    }

    public float getSecondFloatData() {
        return secondFloatData;
    }

    public void setSecondFloatData(float secondFloatData) {
        this.secondFloatData = secondFloatData;
    }

    public Date getMeasureTime() {
        return measureTime;
    }

    public void setMeasureTime(Date measureTime) {
        this.measureTime = measureTime;
    }

    @Override
    public String toString() {
        return "数据包{" +
                ", 第一个数据值=" + firstFloatData +
                ", 第二个数据值=" + secondFloatData +
                ", 传输时间=" + measureTime +
                '}';
    }
}
