package cn.jsu.pojo;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * @author Y
 */
public class DeviceInfo implements Serializable {
    Integer deviceId;
    String deviceEui;
    String device_name;
    String device_addres;
    String device_type;
    Integer device_angle;
    String device_specification;
    Integer deviceVoltag;
    Integer devicePower;
    Integer deviceRange;
    String deviceMark;
    Integer delFlag;
    Timestamp create_date;

    public DeviceInfo(Integer deviceId, String deviceEui, String device_name, String device_addres, String device_type, Integer device_angle, String device_specification, Integer deviceVoltag, Integer devicePower, Integer deviceRange, String deviceMark, Integer delFlag, Timestamp create_date) {
        this.deviceId = deviceId;
        this.deviceEui = deviceEui;
        this.device_name = device_name;
        this.device_addres = device_addres;
        this.device_type = device_type;
        this.device_angle = device_angle;
        this.device_specification = device_specification;
        this.deviceVoltag = deviceVoltag;
        this.devicePower = devicePower;
        this.deviceRange = deviceRange;
        this.deviceMark = deviceMark;
        this.delFlag = delFlag;
        this.create_date = create_date;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceEui() {
        return deviceEui;
    }

    public void setDeviceEui(String deviceEui) {
        this.deviceEui = deviceEui;
    }

    public String getDevice_name() {
        return device_name;
    }

    public void setDevice_name(String device_name) {
        this.device_name = device_name;
    }

    public String getDevice_addres() {
        return device_addres;
    }

    public void setDevice_addres(String device_addres) {
        this.device_addres = device_addres;
    }

    public String getDevice_type() {
        return device_type;
    }

    public void setDevice_type(String device_type) {
        this.device_type = device_type;
    }

    public Integer getDevice_angle() {
        return device_angle;
    }

    public void setDevice_angle(Integer device_angle) {
        this.device_angle = device_angle;
    }

    public String getDevice_specification() {
        return device_specification;
    }

    public void setDevice_specification(String device_specification) {
        this.device_specification = device_specification;
    }

    public Integer getDeviceVoltag() {
        return deviceVoltag;
    }

    public void setDeviceVoltag(Integer deviceVoltag) {
        this.deviceVoltag = deviceVoltag;
    }

    public Integer getDevicePower() {
        return devicePower;
    }

    public void setDevicePower(Integer devicePower) {
        this.devicePower = devicePower;
    }

    public Integer getDeviceRange() {
        return deviceRange;
    }

    public void setDeviceRange(Integer deviceRange) {
        this.deviceRange = deviceRange;
    }

    public String getDeviceMark() {
        return deviceMark;
    }

    public void setDeviceMark(String deviceMark) {
        this.deviceMark = deviceMark;
    }

    public Integer getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(Integer delFlag) {
        this.delFlag = delFlag;
    }

    public Timestamp getCreate_date() {
        return create_date;
    }

    public void setCreate_date(Timestamp create_date) {
        this.create_date = create_date;
    }

    @Override
    public String toString() {
        return "DeviceInfo{" +
                "deviceId=" + deviceId +
                ", deviceEui='" + deviceEui + '\'' +
                ", device_name='" + device_name + '\'' +
                ", device_addres='" + device_addres + '\'' +
                ", device_type='" + device_type + '\'' +
                ", device_angle=" + device_angle +
                ", device_specification='" + device_specification + '\'' +
                ", deviceVoltag=" + deviceVoltag +
                ", devicePower=" + devicePower +
                ", deviceRange=" + deviceRange +
                ", deviceMark='" + deviceMark + '\'' +
                ", delFlag=" + delFlag +
                ", create_date=" + create_date +
                '}';
    }
}
