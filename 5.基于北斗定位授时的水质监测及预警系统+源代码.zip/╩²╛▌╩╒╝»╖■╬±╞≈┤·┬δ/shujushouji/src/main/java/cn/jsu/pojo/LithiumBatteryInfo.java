package cn.jsu.pojo;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author: lyx
 * @date: 2021/10/20/20:34
 * describe:
 **/
@Data
public class LithiumBatteryInfo {
    Integer dataId;
    Integer deviceId;
    Date measureTime;
    BigDecimal batteryVoltage;

    public LithiumBatteryInfo(Integer deviceId, Date measureTime, BigDecimal batteryVoltage) {
        this.deviceId = deviceId;
        this.measureTime = measureTime;
        this.batteryVoltage = batteryVoltage;
    }
}
