package cn.jsu;

import cn.jsu.netty.NettyServerApplication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author: lyx
 * @date: 2021/09/19/21:15
 * describe:
 **/
@SpringBootApplication
public class DataApplication implements CommandLineRunner {

    @Autowired
    NettyServerApplication nettyServerApplication;

    public static void main(String[] args) {
        SpringApplication.run(DataApplication.class,args);
    }

    @Override
    public void run(String... args) throws Exception {
        nettyServerApplication.run();
    }
}
