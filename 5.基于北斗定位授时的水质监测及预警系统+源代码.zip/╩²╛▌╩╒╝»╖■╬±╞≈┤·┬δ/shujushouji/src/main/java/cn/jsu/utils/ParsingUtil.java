package cn.jsu.utils;


import cn.jsu.pojo.PushDataPacket;
import com.google.common.primitives.Longs;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.Random;


/**
 * ParsingUtil定义数据处理线程中使用的方法
 */

public class ParsingUtil {

    private static final byte PUSH_ACK_IDENTIFIER = 0x01;
    private static final byte PUll_ACK_IDENTIFIER = 0x04;

    public static byte[] CalAppNonce(int n) {
        byte[] b = new byte[n];
        Random random = new Random();
        for (int i = 0; i < b.length; i++) {
            b[i] = (byte) random.nextInt(256);
        }
        return b;
    }

    //将数据解析成pushData类型的数据格式
    public static synchronized PushDataPacket getPushDataPacket(byte[] bytes) {
        PushDataPacket pushDataPacket = new PushDataPacket();
        pushDataPacket.setDeviceEui(getDeviceEui(bytes));
        pushDataPacket.setFirstFloatData(getElectricCurrent(bytes));
        pushDataPacket.setSecondFloatData(getElectricTension(bytes));
//        pushDataPacket.setMeasureTime(getMeasureTime(bytes));
        return pushDataPacket;
    }


    //得到设备数据的DeviceEui
    public static synchronized String getDeviceEui(byte[] bytes) {
        return new String(Arrays.copyOfRange(bytes, 1, 9), StandardCharsets.UTF_8);
    }

    //得到电流数据
    public static synchronized float getElectricCurrent(byte[] bytes) {
        return Float.intBitsToFloat(getInt(bytes, 9));
    }

    //得到电压数据
    public static synchronized float getElectricTension(byte[] bytes) {
        return Float.intBitsToFloat(getInt(bytes, 13));
    }

    public static int getInt(byte[] arr, int index) {
        return 	(0xff000000 	& (arr[index] << 24))  |
                (0x00ff0000 	& (arr[index+1] << 16))  |
                (0x0000ff00 	& (arr[index+2] << 8))   |
                (0x000000ff 	&  arr[index+3]);
    }

    //得到发送时间的数据
    public static synchronized Date getMeasureTime(byte[] bytes) {
        long l = (long) Float.intBitsToFloat(getInt(bytes, 17));
//        byte[] bytes1 = Arrays.copyOfRange(bytes, 17, 25);
//        long l = Longs.fromByteArray(bytes1);
        System.out.println(l);
        System.out.println(new Date().getTime());
        return new Date(l);
    }
    //检查包格式是否真确
    public static synchronized boolean checkPacket(byte[] data) {
       //长度小于4
        if (data.length < 4) {
            System.out.println();
            return false;
        }
        //第一个字节不为1-5
        return data[0] == 1
                || data[0] == 2
                || data[0] == 3
                || data[0] == 4
                || data[0] == 5
                || data[0] == 6;
    }

    public static synchronized byte[] getRXPKData(String data) {
        return Base64.getDecoder().decode(data);
    }

    //得到JoinReq中的DevEui
    public static synchronized byte[] getDevEUI(byte[] rxpkdata) {
        return Arrays.copyOfRange(rxpkdata, 9, 17);
    }

    //get DevAddr
    public static byte[] getDevAddr(byte[] rxpkdata) {
        byte[] DevAddr = Arrays.copyOfRange(rxpkdata, 1, 5);
        return DevAddr;
    }


    //序列化为byte[]
    public static byte[] serialize(Object object) {
        ObjectOutputStream oos = null;
        ByteArrayOutputStream bos = null;
        try {
            bos = new ByteArrayOutputStream();
            oos = new ObjectOutputStream(bos);
            oos.writeObject(object);
            byte[] b = bos.toByteArray();
            return b;
        } catch (IOException e) {
            System.out.println("序列化失败 Exception:" + e.toString());
            return null;
        } finally {
            try {
                if (oos != null) {
                    oos.close();
                }
                if (bos != null) {
                    bos.close();
                }
            } catch (IOException ex) {
                System.out.println("io could not close:" + ex.toString());
            }
        }
    }

    //反序列化为Object
    public static Object deserialize(byte[] bytes) {
        ByteArrayInputStream bais = null;
        try {
            // 反序列化
            bais = new ByteArrayInputStream(bytes);
            ObjectInputStream ois = new ObjectInputStream(bais);
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("bytes Could not deserialize:" + e.toString());
            return null;
        } finally {
            try {
                if (bais != null) {
                    bais.close();
                }
            } catch (IOException ex) {
                System.out.println("LogManage Could not serialize:" + ex.toString());
            }
        }
    }

    public static void main(String[] args) {
        byte[] bytes1 = {0x01,0x47, (byte) 0xF6,0x28,0x43, (byte) 0x80,0x01, (byte) 0xCF
                ,0x07,0x3F,0x63, (byte) 0xCE, (byte) 0xBF, 0x40, (byte) 0xE6, (byte) 0xA7, (byte) 0xBC};
        System.out.println(Arrays.toString(bytes1));
        System.out.println(getPushDataPacket(bytes1));

    }
}
