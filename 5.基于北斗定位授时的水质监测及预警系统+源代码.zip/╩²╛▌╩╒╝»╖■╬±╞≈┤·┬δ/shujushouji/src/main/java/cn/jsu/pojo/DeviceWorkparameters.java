package cn.jsu.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;

public class DeviceWorkparameters implements Serializable {
    Integer device_id;
    Integer switch_status;
    Integer channel_switch_status;
    BigDecimal temperature;
    Integer battery;
    Integer operating_hours;
    Integer communication_type;
    BigInteger humidity_report;
    BigInteger electricity_report;
    String upstream_channel;
    String version_number;
    Integer product_number;

    public DeviceWorkparameters(Integer device_id, Integer switch_status, Integer channel_switch_status, BigDecimal temperature, Integer battery, Integer operating_hours, Integer communication_type, BigInteger humidity_report, BigInteger electricity_report, String upstream_channel, String version_number, Integer product_number) {
        this.device_id = device_id;
        this.switch_status = switch_status;
        this.channel_switch_status = channel_switch_status;
        this.temperature = temperature;
        this.battery = battery;
        this.operating_hours = operating_hours;
        this.communication_type = communication_type;
        this.humidity_report = humidity_report;
        this.electricity_report = electricity_report;
        this.upstream_channel = upstream_channel;
        this.version_number = version_number;
        this.product_number = product_number;
    }

    public Integer getDevice_id() {
        return device_id;
    }

    public void setDevice_id(Integer device_id) {
        this.device_id = device_id;
    }

    public Integer getSwitch_status() {
        return switch_status;
    }

    public void setSwitch_status(Integer switch_status) {
        this.switch_status = switch_status;
    }

    public Integer getChannel_switch_status() {
        return channel_switch_status;
    }

    public void setChannel_switch_status(Integer channel_switch_status) {
        this.channel_switch_status = channel_switch_status;
    }

    public BigDecimal getTemperature() {
        return temperature;
    }

    public void setTemperature(BigDecimal temperature) {
        this.temperature = temperature;
    }

    public Integer getBattery() {
        return battery;
    }

    public void setBattery(Integer battery) {
        this.battery = battery;
    }

    public Integer getOperating_hours() {
        return operating_hours;
    }

    public void setOperating_hours(Integer operating_hours) {
        this.operating_hours = operating_hours;
    }

    public Integer getCommunication_type() {
        return communication_type;
    }

    public void setCommunication_type(Integer communication_type) {
        this.communication_type = communication_type;
    }

    public BigInteger getHumidity_report() {
        return humidity_report;
    }

    public void setHumidity_report(BigInteger humidity_report) {
        this.humidity_report = humidity_report;
    }

    public BigInteger getElectricity_report() {
        return electricity_report;
    }

    public void setElectricity_report(BigInteger electricity_report) {
        this.electricity_report = electricity_report;
    }

    public String getUpstream_channel() {
        return upstream_channel;
    }

    public void setUpstream_channel(String upstream_channel) {
        this.upstream_channel = upstream_channel;
    }

    public String getVersion_number() {
        return version_number;
    }

    public void setVersion_number(String version_number) {
        this.version_number = version_number;
    }

    public Integer getProduct_number() {
        return product_number;
    }

    public void setProduct_number(Integer product_number) {
        this.product_number = product_number;
    }

    @Override
    public String toString() {
        return "DeviceWorkparameters{" +
                "device_id=" + device_id +
                ", switch_status=" + switch_status +
                ", channel_switch_status=" + channel_switch_status +
                ", temperature=" + temperature +
                ", battery=" + battery +
                ", operating_hours=" + operating_hours +
                ", communication_type=" + communication_type +
                ", humidity_report=" + humidity_report +
                ", electricity_report=" + electricity_report +
                ", upstream_channel='" + upstream_channel + '\'' +
                ", version_number='" + version_number + '\'' +
                ", product_number=" + product_number +
                '}';
    }
}
