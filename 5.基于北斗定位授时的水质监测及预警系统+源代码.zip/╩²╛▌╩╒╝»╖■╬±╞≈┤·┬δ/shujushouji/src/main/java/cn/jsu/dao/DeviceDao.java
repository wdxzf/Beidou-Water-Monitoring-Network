package cn.jsu.dao;

import cn.jsu.pojo.DataInfo;
import cn.jsu.pojo.ExtraDataInfo;
import cn.jsu.pojo.LithiumBatteryInfo;
import cn.jsu.pojo.LocateInfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @author: lyx
 * @date: 2021/09/20/00:02
 * describe:
 **/
@Mapper
@Repository
public interface DeviceDao {
    int insertElectricData(DataInfo dataInfo);

    int insertLocateInfo(LocateInfo locateInfo);

    int insertTemperatureAndHumidity(ExtraDataInfo extraDataInfo);

    int insertBatteryVoltageInfo(LithiumBatteryInfo lithiumBatteryInfo);

    Integer selectDeviceByEui(String deviceEui);
}

