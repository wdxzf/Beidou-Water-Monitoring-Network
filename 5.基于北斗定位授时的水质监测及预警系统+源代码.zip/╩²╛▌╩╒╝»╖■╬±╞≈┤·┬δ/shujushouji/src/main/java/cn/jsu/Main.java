package cn.jsu;

import com.google.common.primitives.Longs;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.*;
import java.util.Arrays;
import java.util.Date;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author: lyx
 * @date: 2021/09/20/00:22
 * describe:
 **/
public class Main {
    static LinkedBlockingQueue<DatagramPacket> queue = new LinkedBlockingQueue<>();
    static DatagramSocket socket;
    static InetAddress groupAddress;
    static int PORT = 7777;
    static {
        try {
            socket = new DatagramSocket();
            groupAddress = InetAddress.getByName("1.14.102.69");
        } catch (SocketException | UnknownHostException e) {
            e.printStackTrace();
        }
    }
    public static void main(String[] args) throws InterruptedException, InvalidFormatException, IOException {
            new Thread(()->{
                while (true){
                    try {
                        DatagramPacket take = queue.take();
                        socket.send(take);
                        Thread.sleep(2500);
                    } catch (InterruptedException | IOException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
//            new Thread(()->{
//                try {
//                    du("北斗数据", ((byte) 0x05));
//                } catch (IOException | InvalidFormatException | InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }).start();
//        new Thread(()->{
//            try {
//                du("光伏数据", ((byte) 0x01));
//            } catch (IOException | InvalidFormatException | InterruptedException e) {
//                e.printStackTrace();
//            }
//        }).start();
        du("光伏数据", ((byte) 0x01));
    }

    public static void du(String xlsName,byte packType) throws IOException, InvalidFormatException, InterruptedException {
        FileInputStream fileInputStream = new FileInputStream(new File("C:\\Users\\Y\\Desktop\\"+xlsName+".xls"));
        Workbook workbook = WorkbookFactory.create(fileInputStream);
        Sheet sheet = workbook.getSheetAt(0);
        int rowNumber = sheet.getPhysicalNumberOfRows();
        System.out.println(rowNumber);
        for (int i = 1; i < rowNumber; i++) {
            Row row = sheet.getRow(i);
            int cellNumber = row.getPhysicalNumberOfCells();
            byte[] bytes = new byte[25];
            bytes[0] = packType;
            int flag = 0;
            for (int j = 0; j < cellNumber; j++) {

                Cell cell = row.getCell(j);
                int cellType = cell.getCellType();
                switch (cellType) {
                    case Cell.CELL_TYPE_STRING:
                        String stringCellValue = cell.getStringCellValue();
                        System.arraycopy(stringCellValue.getBytes(),0,bytes,1,stringCellValue.getBytes().length);
                        break;
                    case Cell.CELL_TYPE_NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            Date dateCellValue = cell.getDateCellValue();
                            long time = dateCellValue.getTime();
                            byte[] bytes1 = Longs.toByteArray(time);
                            System.arraycopy(bytes1,0,bytes,17,bytes1.length);
                        } else {

                            double aDouble = cell.getNumericCellValue();
                            float v = (float) aDouble;
                            byte[] byteArray = getByteArray(Float.floatToIntBits(v));
                            System.out.println(Arrays.toString(byteArray));
                            System.arraycopy(byteArray,0,bytes,9+flag,byteArray.length);
                            flag=flag+4;
                        }
                        break;
                    default:
                }
            }
            System.out.println(Arrays.toString(bytes));
            DatagramPacket datagramPacket = new DatagramPacket(bytes, bytes.length, groupAddress, PORT);
            queue.put(datagramPacket);
        }
    }

    public static byte[] getByteArray(int i) {
        byte[] b = new byte[4];
        b[0] = (byte) ((i & 0xff000000) >> 24);
        b[1] = (byte) ((i & 0x00ff0000) >> 16);
        b[2] = (byte) ((i & 0x0000ff00) >> 8);
        b[3] = (byte)  (i & 0x000000ff);
        return b;
    }
}
